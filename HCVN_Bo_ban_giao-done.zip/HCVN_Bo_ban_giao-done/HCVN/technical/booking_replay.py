"""Acceptance fixture for the proposed booking ledger. Local, no cloud connection."""
import sqlite3

def verify():
    db = sqlite3.connect(":memory:")
    db.executescript("""
        CREATE TABLE ledger(event_id TEXT PRIMARY KEY, booking TEXT, version INTEGER, state TEXT,
                            net_paid INTEGER, UNIQUE(booking,version));
        CREATE TABLE booking_state(booking TEXT PRIMARY KEY, version INTEGER, state TEXT, net_paid INTEGER);
    """)
    # Source publishes full snapshots with cumulative net amount, in VND.
    events = [
        ("P2","B17",2,"PAID",300000),          # arrives before version 1
        ("C1","B17",1,"CREATED",0),
        ("P2","B17",2,"PAID",300000),          # retry after a write
        ("R3","B17",3,"REFUNDED",0),
        ("P2","B17",2,"PAID",300000),          # historical replay
    ]
    history=[]
    for event in events:
        with db:
            recorded=db.execute("SELECT * FROM ledger WHERE event_id=?",(event[0],)).fetchone()
            if recorded and recorded!=event:
                raise ValueError("Conflicting event payload")
            if recorded is None:
                db.execute("INSERT INTO ledger VALUES (?,?,?,?,?)",event)
                db.execute("""INSERT INTO booking_state VALUES (?,?,?,?)
                    ON CONFLICT(booking) DO UPDATE SET version=excluded.version,
                    state=excluded.state, net_paid=excluded.net_paid
                    WHERE excluded.version>booking_state.version""",event[1:])
        history.append(db.execute("SELECT count(*),sum(net_paid) FROM booking_state").fetchone())
    assert history==[(1,300000)]*3+[(1,0)]*2
    assert db.execute("SELECT count(*) FROM ledger").fetchone()[0]==3
    assert db.execute("SELECT version, state FROM booking_state").fetchone()==(3,"REFUNDED")
    db.close()
    return history

if __name__=="__main__":
    for n,(bookings,net) in enumerate(verify(),1):
        print(n,bookings,net)
