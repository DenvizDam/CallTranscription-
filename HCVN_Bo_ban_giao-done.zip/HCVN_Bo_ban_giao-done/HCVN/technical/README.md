# HCVN Entertainment Operations

Dự án mô phỏng luồng dữ liệu vận hành giải trí, từ lượt xem, đặt vé và thanh toán đến check-in, hủy vé và hoàn tiền.

```mermaid
flowchart LR
    A["Producer · SQLite outbox"] --> B["Kafka"]
    B --> C["Consumer"]
    C --> D["Kho sự kiện gốc · JSON"]
    C --> E["Oracle · EVENT_LOG"]
    E --> F["Các view báo cáo"]
    F --> G["Power BI Desktop"]
    D --> H["Replay"]
    H --> E
```

## 1. Chạy demo nhanh bằng Python

Mở PowerShell tại thư mục `technical` có file README này. Cần Python 3.12. Hai lệnh sau dùng SQLite trong bộ nhớ và thư viện chuẩn của Python.

```powershell
python -B live/local_demo.py --terminal
python -B booking_replay.py
```

Lệnh đầu hiển thị các chỉ số sau từng sự kiện trong kịch bản 10 bước. Lệnh thứ hai kiểm tra trường hợp sự kiện booking đến sai thứ tự, gửi trùng và được phát lại.

## 2. Chạy pipeline Kafka và Oracle

Cần Docker Desktop đang chạy ở chế độ Linux containers, Docker Compose v2 và cổng `1521` còn trống trên máy. Chạy các lệnh sau từ thư mục `technical`.

```powershell
cd live
docker compose up -d --build
docker compose ps
docker compose logs -f consumer
```

Đợi đến khi log hiện `Reporting views ready`, rồi nhấn **Ctrl+C** để thoát chế độ theo dõi log. Các container vẫn chạy nền. Nếu container chưa khởi động, xem trạng thái bằng `docker compose ps -a` và log bằng `docker compose logs --tail 50 kafka oracle consumer`.

Gửi 10 sự kiện mẫu vào môi trường mới. Tham số `--interval 0` gửi liên tiếp. Đổi thành `--interval 8` để theo dõi sự kiện xuất hiện từng bước trên dashboard.

```powershell
docker compose --profile demo run --rm --build --no-deps producer publish --interval 0 --limit 10
```

Kiểm tra dữ liệu Oracle ngay từ container consumer.

```powershell
docker compose exec -T consumer python -c "from pipeline import warehouse; db = warehouse(); print(db.cursor().execute('SELECT events_seen, active_seats, net_vnd, watch_min, check_ins FROM V_LIVE').fetchall())"
```

Sau khi consumer xử lý xong, môi trường mới trả về **10 sự kiện, 1 booking đang hoạt động, 180.000 VND doanh thu ròng, 20 phút xem và 1 lượt check-in**. Nếu vừa chạy producer và số đếm còn thấp, đợi vài giây rồi truy vấn lại.

### Gửi thêm một sự kiện

Producer lưu tiến độ trong volume Docker. `--limit` là tổng số bước đến thời điểm dừng. Sau khi đã gửi 10 sự kiện, tăng giới hạn lên 11 để gửi đúng một sự kiện nữa.

```powershell
docker compose --profile demo run --rm --no-deps producer publish --interval 0 --limit 11
```

Sự kiện `0002-01` có loại `WATCHED` và giá trị 12 phút. Chạy lại truy vấn `V_LIVE` để thấy **11 sự kiện và 32 phút xem**. Nếu đã chạy đến bước 11, dùng giới hạn 12 để gửi thêm một sự kiện tiếp theo.

### Phát lại kho sự kiện

```powershell
docker compose exec -T consumer python -m pipeline replay
```

Lệnh đọc các bản JSON đã lưu và xử lý lại vào Oracle. Chạy lại truy vấn `V_LIVE` để kiểm tra số liệu. Các sự kiện đã xử lý được nhận diện bằng `event_id`.

## 3. Mở dashboard Power BI

Trên Windows có Power BI Desktop, mở file [Entertainment.pbip](live/Entertainment.pbip) sau khi consumer báo sẵn sàng. Nếu Power BI yêu cầu thông tin kết nối, dùng cấu hình demo sau.

| Thông tin | Giá trị |
| --- | --- |
| Máy chủ Oracle | `localhost:1521/FREEPDB1` |
| Tên người dùng | `HCVN` |
| Mật khẩu demo | `HcvnDemo2026` |

Để xem thay đổi theo từng sự kiện, bật **Page refresh** trong định dạng trang, chọn **Fixed interval** và đặt **5 giây**. Sau đó chạy lệnh producer với `--interval 8`. Thư mục `live` cũng có [Start_dashboard.cmd](live/Start_dashboard.cmd) để khởi động dịch vụ, mở báo cáo và chờ bạn nhấn phím trước khi gửi kịch bản 10 sự kiện.

## 4. Dừng dịch vụ

Chạy từ thư mục `live`.

```powershell
docker compose --profile demo down
```

Lệnh giữ các volume Kafka, Oracle và dữ liệu pipeline. Lần khởi động sau sẽ tiếp tục từ dữ liệu và tiến độ producer đã lưu.
