"""Run a source simulator, a Kafka consumer, or replay the raw archive."""
import argparse
import base64
import json
import os
import sqlite3
import time
from pathlib import Path

import oracledb
from confluent_kafka import Consumer, Producer
from confluent_kafka.admin import AdminClient, NewTopic
from confluent_kafka import KafkaError, KafkaException
from events import TOPIC, apply, event, setup

BROKER = {'bootstrap.servers':'kafka:9092'}
TOPICS = sorted(set(TOPIC.values()))
DATA = Path('/state')
RAW = DATA/'raw'

def warehouse():
    return oracledb.connect(user='HCVN', password=os.environ['APP_PASSWORD'], dsn='oracle:1521/FREEPDB1')

def publish(interval, limit):
    admin = AdminClient(BROKER)
    for future in admin.create_topics([NewTopic(t, 1, 1) for t in TOPICS]).values():
        try:
            future.result()
        except KafkaException as exc:
            if exc.args[0].code() != KafkaError.TOPIC_ALREADY_EXISTS:
                raise
    source = sqlite3.connect(DATA/'source.sqlite')
    source.execute('CREATE TABLE IF NOT EXISTS outbox (step INTEGER PRIMARY KEY, body TEXT, sent INTEGER)')
    producer = Producer({**BROKER, 'enable.idempotence':True})
    while True:
        row = source.execute('SELECT step,body FROM outbox WHERE sent=0 ORDER BY step LIMIT 1').fetchone()
        if row is None:
            step = source.execute('SELECT COALESCE(MAX(step)+1,0) FROM outbox').fetchone()[0]
            if limit and step >= limit:
                return
            body = json.dumps(event(step))
            with source:
                source.execute('INSERT INTO outbox VALUES (?,?,0)', (step,body))
        else:
            step, body = row
        e = json.loads(body)
        errors = []
        def confirmed(err, msg):
            if err:
                errors.append(str(err))
        producer.produce(TOPIC[e['kind']],key=e['entity_id'],value=body,on_delivery=confirmed)
        if producer.flush(30) or errors:
            raise RuntimeError(f'Kafka delivery failed: {errors}')
        with source:
            source.execute('UPDATE outbox SET sent=1 WHERE step=?',(step,))
        print(e['event_id'], e['kind'], flush=True)
        time.sleep(interval)

def save_record(path, record):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(record),encoding='utf8')
    tmp.replace(path)

def ingest(db, record, name):
    try:
        payload = json.loads(base64.b64decode(record['body']))
        if not isinstance(payload, dict):
            raise ValueError('Expected a JSON object')
        if TOPIC.get(payload.get('kind')) != record['topic']:
            raise ValueError('Unexpected topic for event')
        apply(db, payload)
    except (ValueError, KeyError, TypeError) as exc:
        db.rollback()
        save_record(DATA/'rejected'/name,{**record,'error':str(exc)})

def consume():
    db = warehouse()
    setup(db, oracle=True)
    c = Consumer({**BROKER,'group.id':'hcvn-live-v1','enable.auto.commit':False,'auto.offset.reset':'earliest'})
    c.subscribe(TOPICS)
    print('Reporting views ready',flush=True)
    try:
        while True:
            msg = c.poll(1)
            if msg is None:
                continue
            if msg.error():
                if msg.error().code() == KafkaError.UNKNOWN_TOPIC_OR_PART:
                    time.sleep(1)
                    continue
                raise KafkaException(msg.error())
            name = f'{msg.topic()}-{msg.partition()}-{msg.offset():012}.json'
            rec = {'topic':msg.topic(),'partition':msg.partition(),'offset':msg.offset(),
                   'body':base64.b64encode(msg.value() or b'').decode()}
            save_record(RAW/name,rec)
            ingest(db,rec,name)
            c.commit(message=msg,asynchronous=False)
    finally:
        c.close()
        db.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['publish','consume','replay'])
    parser.add_argument('--interval',type=float,default=8)
    parser.add_argument('--limit',type=int,default=0)
    args=parser.parse_args()
    if args.action=='publish':
        publish(args.interval,args.limit)
    elif args.action=='consume':
        consume()
    else:
        with warehouse() as db:
            for file in sorted(RAW.glob('*.json')):
                ingest(db,json.loads(file.read_text()),file.name)
        print('Archive replay complete')
