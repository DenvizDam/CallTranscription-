CREATE VIEW V_FACT AS
WITH ranked AS (
  SELECT e.*, ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY revision DESC, event_id DESC) AS latest
  FROM event_log e
)
SELECT r.*,
  CASE WHEN kind='BOOKED' AND latest=1 THEN 1 ELSE 0 END AS active_booking,
  CASE WHEN kind='CANCELLED' AND latest=1 THEN 1 ELSE 0 END AS cancelled_booking,
  CASE WHEN kind='PAID' THEN qty WHEN kind='REFUNDED' THEN -qty ELSE 0 END AS receipts,
  CASE WHEN kind='WATCHED' THEN qty ELSE 0 END AS minutes_seen,
  CASE WHEN kind='CHECKED_IN' AND latest=1 THEN 1 ELSE 0 END AS admission,
  CASE WHEN kind='SUBSCRIBED' AND latest=1 THEN 1 ELSE 0 END AS active_member
FROM ranked r;

CREATE VIEW V_SHOW AS
SELECT s.show_id, s.capacity,
  COUNT(DISTINCT CASE WHEN f.kind='WATCHED' THEN f.customer_id END) AS viewers,
  COALESCE(SUM(minutes_seen),0) AS watch_min,
  COALESCE(SUM(active_booking),0) AS active_seats,
  COALESCE(SUM(cancelled_booking),0) AS cancelled,
  COALESCE(SUM(admission),0) AS check_ins,
  ROUND(100.0 * COALESCE(SUM(active_booking),0)/s.capacity,1) AS booked_pct,
  COALESCE(SUM(receipts),0) AS net_vnd
FROM shows s LEFT JOIN V_FACT f ON s.show_id=f.show_id
GROUP BY s.show_id,s.capacity;

CREATE VIEW V_CUSTOMER AS
SELECT customer_id, MAX(active_member) AS member_active, SUM(minutes_seen) AS watch_min,
       SUM(active_booking) AS active_seats, SUM(admission) AS check_ins, SUM(receipts) AS net_vnd,
       MAX(event_utc) AS last_seen_utc
FROM V_FACT GROUP BY customer_id;

CREATE VIEW V_LIVE AS
SELECT COUNT(*) AS events_seen, COALESCE(SUM(active_booking),0) AS active_seats,
       COALESCE(SUM(receipts),0) AS net_vnd, COALESCE(SUM(minutes_seen),0) AS watch_min,
       COALESCE(SUM(admission),0) AS check_ins, MAX(event_utc) AS latest_utc
FROM V_FACT;

CREATE VIEW V_RECENT AS
SELECT event_id,kind,customer_id,show_id,booking_id,event_utc,
       CASE WHEN kind='PAID' THEN qty WHEN kind='REFUNDED' THEN -qty END AS cash_vnd FROM (
  SELECT e.*, ROW_NUMBER() OVER (ORDER BY event_utc DESC,event_id DESC) AS seq_num FROM event_log e
) ranked_events WHERE seq_num<=10;
