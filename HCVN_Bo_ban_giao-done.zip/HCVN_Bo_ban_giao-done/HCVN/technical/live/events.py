from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIELDS = ('event_id', 'kind', 'entity_id', 'revision', 'customer_id', 'show_id', 'qty', 'event_utc', 'booking_id')
SHOWS = [('City Lights', 120), ('Summer Live', 80)]
# Each row is one action. A booking has one seat. Payments use VND.
STEPS = [
    ('WATCHED', 'view1', 1, 'C01', 'City Lights', 12),
    ('BOOKED', 'ticket1', 1, 'C01', 'City Lights', 1),
    ('PAID', 'charge1', 1, 'C01', 'City Lights', 300000),
    ('SUBSCRIBED', 'member1', 1, 'C01', None, 1),
    ('WATCHED', 'view2', 1, 'C02', 'Summer Live', 8),
    ('BOOKED', 'ticket2', 1, 'C02', 'Summer Live', 1),
    ('PAID', 'charge2', 1, 'C02', 'Summer Live', 180000),
    ('CHECKED_IN', 'scan2', 1, 'C02', 'Summer Live', 1),
    ('CANCELLED', 'ticket1', 2, 'C01', 'City Lights', 1),
    ('REFUNDED', 'refund1', 1, 'C01', 'City Lights', 300000),
]
TOPIC = {'WATCHED':'views', 'BOOKED':'bookings', 'CANCELLED':'bookings', 'PAID':'bookings',
         'REFUNDED':'bookings', 'SUBSCRIBED':'memberships', 'CHECKED_IN':'attendance'}

def event(step):
    batch, index = divmod(step, len(STEPS))
    kind, entity, revision, customer, show, qty = STEPS[index]
    prefix = f'{batch + 1:04d}'
    stamp = datetime.now(timezone.utc).isoformat(timespec='seconds')
    booking_key = {'ticket1':'ticket1', 'charge1':'ticket1', 'refund1':'ticket1',
                   'ticket2':'ticket2', 'charge2':'ticket2', 'scan2':'ticket2'}.get(entity)
    booking_id = f'{prefix}-{booking_key}' if booking_key else None
    return dict(zip(FIELDS, [f'{prefix}-{index+1:02d}', kind, f'{prefix}-{entity}', revision,
                             f'{prefix}-{customer}', show, qty, stamp, booking_id]))

def validate(e):
    for k in ('event_id', 'entity_id', 'customer_id', 'event_utc'):
        if not isinstance(e.get(k), str) or not 0 < len(e[k]) <= 64:
            raise ValueError(f'Invalid {k}')
    if e.get('kind') not in TOPIC or type(e.get('revision')) is not int or e['revision'] < 1:
        raise ValueError('Unknown event or invalid revision')
    if e['kind'] in {'BOOKED','CANCELLED','PAID','REFUNDED','CHECKED_IN'} and not e.get('booking_id'):
        raise ValueError('Missing booking reference')
    if type(e.get('qty')) is not int or e['qty'] < 0:
        raise ValueError('Invalid quantity')
    if e['kind'] != 'SUBSCRIBED' and e.get('show_id') not in dict(SHOWS):
        raise ValueError('Unknown show')
    if datetime.fromisoformat(e['event_utc']).utcoffset() != timezone.utc.utcoffset(None):
        raise ValueError('Expected UTC timestamp')

def setup(db, oracle=False):
    cur = db.cursor()
    ddl = ['CREATE TABLE event_log (event_id VARCHAR(64) PRIMARY KEY, kind VARCHAR(20), '
           'entity_id VARCHAR(64), revision INTEGER, customer_id VARCHAR(64), show_id VARCHAR(64), '
           'qty INTEGER, event_utc VARCHAR(64), booking_id VARCHAR(64))',
           'CREATE TABLE shows (show_id VARCHAR(64) PRIMARY KEY, capacity INTEGER)']
    for stmt in ddl:
        if not oracle:
            stmt = stmt.replace('CREATE TABLE', 'CREATE TABLE IF NOT EXISTS')
        try:
            cur.execute(stmt)
        except Exception as exc:
            if not oracle or getattr(exc.args[0], 'code', 0) != 955:
                raise
    for show, capacity in SHOWS:
        cur.execute('SELECT COUNT(*) FROM shows WHERE show_id=:s', {'s': show})
        if not cur.fetchone()[0]:
            cur.execute('INSERT INTO shows VALUES (:s,:c)', {'s':show,'c':capacity})
    for stmt in (HERE/'reporting.sql').read_text().split(';'):
        if stmt.strip():
            cur.execute(stmt.replace('CREATE VIEW', 'CREATE OR REPLACE VIEW' if oracle else 'CREATE VIEW IF NOT EXISTS'))
    db.commit()
    cur.close()

def apply(db, e):
    validate(e)
    cur = db.cursor()
    try:
        cur.execute('SELECT '+','.join(FIELDS)+' FROM event_log WHERE event_id=:event_id',
                    {'event_id':e['event_id']})
        existing = cur.fetchone()
        if existing is None:
            cur.execute('INSERT INTO event_log VALUES (' + ','.join(':'+f for f in FIELDS)+')',
                        {k:e[k] for k in FIELDS})
        elif tuple(existing) != tuple(e[k] for k in FIELDS):
            raise ValueError('Same event ID with different payload')
        db.commit()
    finally:
        cur.close()
