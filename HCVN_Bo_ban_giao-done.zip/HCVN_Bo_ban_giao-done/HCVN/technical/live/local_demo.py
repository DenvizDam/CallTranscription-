"""A ten-event desktop walkthrough using the same reporting SQL as the live project."""
import argparse
import sqlite3
from events import STEPS, event, setup, apply

def records(db, view):
    return db.execute('SELECT * FROM '+view).fetchall()

def run(window=True):
    db=sqlite3.connect(':memory:')
    setup(db)
    if not window:
        print('Event       | Active bookings | Net receipts (VND) | Minutes | Check-ins')
        for i in range(len(STEPS)):
            e=event(i)
            apply(db,e)
            _, seats, net, minutes, checkins, _ = records(db,'V_LIVE')[0]
            print(f"{e['kind']:11} | {seats:15} | {net:18,} | {minutes:7} | {checkins:9}")
        return
    import tkinter as tk
    from tkinter import ttk
    root=tk.Tk()
    root.title('Entertainment operations | Local walkthrough')
    root.geometry('960x555')
    shell=ttk.Frame(root,padding=16)
    shell.pack(fill='both',expand=True)
    shell.columnconfigure(0,weight=1)
    ttk.Label(shell,text='Entertainment operations',font=('Arial',20,'bold')).grid(sticky='w')
    source=tk.StringVar(value='Ready | Sample data | One seat per booking, all payments in VND')
    ttk.Label(shell,textvariable=source).grid(sticky='w',pady=6)
    kpis=tk.StringVar()
    ttk.Label(shell,textvariable=kpis,font=('Arial',13,'bold')).grid(sticky='w',pady=9)
    grids=[]
    for title,view,headers in [
        ('Show performance','V_SHOW',('Show','Capacity','Viewers','Watch min','Active seats','Cancelled','Check-ins','Booked %','Net VND')),
        ('Customer 360','V_CUSTOMER',('Customer','Member (1=yes)','Watch min','Active seats','Check-ins','Net VND','Last activity (UTC)'))]:
        ttk.Label(shell,text=title,font=('Arial',12,'bold')).grid(sticky='w',pady=(8,2))
        tree=ttk.Treeview(shell,columns=headers,show='headings',height=3)
        for h in headers:
            tree.heading(h,text=h)
            tree.column(h,width=80 if h!='Last activity (UTC)' else 190,anchor='center')
        tree.grid(sticky='ew')
        grids.append((tree,view))
    controls=ttk.Frame(shell)
    controls.grid(sticky='w',pady=10)
    step=0
    timer=None
    def paint():
        _,seats,net,minutes,checks,_=records(db,'V_LIVE')[0]
        kpis.set(f'Active bookings  {seats}       Net receipts  {net:,} VND       Watch time  {minutes} min       Check-ins  {checks}')
        for tree,view in grids:
            tree.delete(*tree.get_children())
            for row in records(db,view):
                tree.insert('','end',values=row)
    def advance():
        nonlocal step
        if step==len(STEPS):
            return
        e=event(step)
        apply(db,e)
        step+=1
        source.set(f"{step:02d}/10   {e['kind']}   ·   {e['customer_id']}   ·   {e['show_id'] or 'Membership'}   ·   {e['event_utc']}")
        paint()
    def pause():
        nonlocal timer
        if timer is not None:
            root.after_cancel(timer)
            timer=None
    def auto():
        nonlocal timer
        pause()
        advance()
        if step<len(STEPS):
            timer=root.after(3000,auto)
    def reset():
        nonlocal step
        pause()
        db.execute('DELETE FROM event_log')
        db.commit()
        step=0
        source.set('Ready | Sample data')
        paint()
    for label,fn in [('Next event',advance),('Play',auto),('Pause',pause),('Restart',reset)]:
        ttk.Button(controls,text=label,command=fn).pack(side='left',padx=3)
    paint()
    root.mainloop()

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--terminal',action='store_true')
    run(not p.parse_args().terminal)
