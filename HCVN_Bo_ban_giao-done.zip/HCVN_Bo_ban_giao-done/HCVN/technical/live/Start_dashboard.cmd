@echo off
setlocal
cd /d "%~dp0"
docker compose up -d --build
if errorlevel 1 goto failed
echo Waiting for the Oracle reporting views...
for /l %%G in (1,1,90) do (
  docker compose logs --no-color consumer 2>nul | findstr /c:"Reporting views ready" >nul && goto openreport
  timeout /t 2 /nobreak >nul
)
docker compose logs --tail 25 consumer
goto failed
:openreport
start "" "Entertainment.pbip"
echo In Power BI, connect using HCVN / HcvnDemo2026.
echo Set Page refresh to On, Fixed interval, 5 seconds.
echo Press any key once the report is open to send 10 events.
pause >nul
docker compose --profile demo run --rm --build --no-deps producer
if errorlevel 1 goto failed
echo Finished. A previous completed run keeps its data.
echo To stop services later, run: docker compose --profile demo down
pause
exit /b 0
:failed
echo The walkthrough could not start. Check Docker Desktop and the guide.
pause
exit /b 1
