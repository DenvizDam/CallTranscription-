# Power BI • Giữ chân khách hàng tất toán trước hạn

**Nguồn**: workbook gốc đi kèm đề. Các truy vấn đọc thẳng sheet ẩn `PBI`; không cần bật hiển thị sheet. Chúng nhận diện ba tiêu đề trong đúng bố cục đề. Nếu nguồn chuyển thành bảng nghiệp vụ, thay riêng bước đọc dữ liệu.

1. Trong Power BI Desktop, tạo text parameter `WorkbookPath` với đường dẫn đến file đề. Trong Transform data, tạo bốn blank query theo đúng tên file (bỏ đuôi .pq), theo thứ tự `SourcePBI`, `Agents`, `Loans`, `Calls`. Dán từng nội dung vào Advanced Editor. Tắt Enable load cho SourcePBI và Loans. Loans là bảng tra ở cấp hợp đồng trong mẫu, được merge vào Calls bằng left join để giữ cả cuộc gọi thiếu hồ sơ.
2. Chọn Close & Apply. Tạo quan hệ `Agents[Employee ID]` (1) → `Calls[EMPLOYEE]` (*), lọc một chiều. Tạo bảng Calendar bằng biểu thức cuối file measures.dax, đánh dấu Date table rồi nối Calendar[Date] (1) → Calls[CALL_DATE] (*). Hai bảng chiều lọc Calls độc lập.
3. Tạo từng measure trong `measures.dax`. Định dạng Retention Success Rate là %. Mẫu số là tất cả lượt gọi trong bộ lọc, gồm cả Review. Không tính trung bình các tỷ lệ của nhân viên.
4. Trang tổng quan: bốn thẻ Total Calls, Status Qualified, Successful Calls, Retention Success Rate. Matrix theo Agents[Team] và Agents[Employee ID], values Total Calls, Successful Calls, Retention Success Rate. Thêm bảng tương tự theo OFFER_TYPE. Bật Show items with no data nếu cần hiện nhân viên không có cuộc gọi. Dùng slicer theo Calendar[Date] và Agents[Team].
5. Trang kiểm tra: CALL_ID, CONTRACT_ID, CALL_DATE, DATE_SIGN, TENOR, MIDPOINT_DAY, REQ_STATUS, STATUS_OK, AFTER_HALF, CALL_RESULT, OUTCOME. Thêm thẻ Review Calls. Đối chiếu với results/retention_audit.csv. Tỷ lệ trong mẫu là 2/10. Ô OFFER_TYPE trống là thiếu thông tin, còn “No Voucher” là giá trị có thật.
6. Tệp .pq và .dax là mã để triển khai. Kết quả mẫu đã đối soát bằng Python. Chưa chạy M/DAX trên Power BI Desktop. Dashboard mẫu và bảng dữ liệu kiểm tra nằm trong báo cáo PDF.
