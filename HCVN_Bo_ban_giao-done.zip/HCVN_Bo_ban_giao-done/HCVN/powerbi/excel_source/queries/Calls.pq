let
    Fields = Table.SelectColumns(SourcePBI, {"Column1","Column2","Column3","Column4","Column5","Column6","Column7"}),
    FromHeader = Table.Skip(Fields, each [Column1] <> "CALL_ID"),
    Data = Table.PromoteHeaders(FromHeader),
    Rows = Table.FirstN(Data, each [CALL_ID] <> null),
    Typed = Table.TransformColumnTypes(Rows, {{"CALL_ID", Int64.Type},{"CONTRACT_ID",type text},{"CUID",type text},{"CALL_DATE",type date},{"EMPLOYEE",type text},{"CALL_RESULT",type text},{"OFFER_TYPE",type text}}),
    Clean = Table.ReplaceValue(Typed,"NULL",null,Replacer.ReplaceValue,{"OFFER_TYPE"}),
    Checked = if Table.IsDistinct(Clean, {"CALL_ID"}) then Clean else error "Duplicate CALL_ID",
    Matched = Table.NestedJoin(Checked, {"CONTRACT_ID"}, Loans, {"CONTRACT_ID"}, "Loan", JoinKind.LeftOuter),
    Expanded = Table.ExpandTableColumn(Matched,"Loan",{"DATE_SIGN","TENOR","REQ_STATUS"}),
    Midpoint = Table.AddColumn(Expanded,"MIDPOINT_DAY", each
        let
            s = Date.From([DATE_SIGN]), t = [TENOR],
            valid = s <> null and t <> null and t > 0 and Number.RoundDown(t) = t,
            lower = if valid then Date.AddMonths(s,Number.IntegerDivide(t,2)) else null,
            upper = if valid then Date.AddMonths(s,Number.IntegerDivide(t,2)+1) else null
        in if not valid then null else if Number.Mod(t,2)=0 then lower
           else Date.AddDays(lower,Number.IntegerDivide(Duration.Days(upper-lower),2)), type nullable date),
    Status = Table.AddColumn(Midpoint,"STATUS_OK",each
        if [REQ_STATUS]="EXECUTED" then false
        else if List.Contains({"CANCELLED","EXPIRE"},[REQ_STATUS]) then true else null, type nullable logical),
    Timing = Table.AddColumn(Status,"AFTER_HALF",each
        if [CALL_DATE]=null or [MIDPOINT_DAY]=null or [CALL_DATE]<Date.From([DATE_SIGN]) or [CALL_DATE]=[MIDPOINT_DAY]
        then null else [CALL_DATE]>[MIDPOINT_DAY], type nullable logical),
    Scored = Table.AddColumn(Timing,"OUTCOME",each
        if [STATUS_OK]=null or [CALL_DATE]=null or [MIDPOINT_DAY]=null or [CALL_DATE]<Date.From([DATE_SIGN]) then "Review"
        else if [STATUS_OK]=false or [AFTER_HALF]=false then "Fail"
        else if [AFTER_HALF]=null then "Review" else "Success",type text)
in
    Scored
