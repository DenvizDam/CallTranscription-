let
    Fields = Table.SelectColumns(SourcePBI, {"Column9", "Column10", "Column11", "Column12"}),
    FromHeader = Table.Skip(Fields, each [Column9] <> "Employee ID"),
    Rows = Table.SelectRows(Table.PromoteHeaders(FromHeader), each [Employee ID] <> null),
    Typed = Table.TransformColumnTypes(Rows, {{"Employee ID",type text},{"Team",type text},{"Start Date",type date},{"Gender",type text}}),
    Checked = if Table.IsDistinct(Typed, {"Employee ID"}) then Typed else error "Duplicate Employee ID"
in
    Checked
