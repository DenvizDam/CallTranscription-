let
    Sheets = Excel.Workbook(File.Contents(WorkbookPath), null, true),
    Data = Sheets{[Item="PBI", Kind="Sheet"]}[Data]
in
    Data
