let
    Fields = Table.SelectColumns(SourcePBI, {"Column1","Column2","Column3","Column4"}),
    FromHeader = Table.Skip(Fields, each [Column1] <> "CONTRACT_ID"),
    Rows = Table.SelectRows(Table.PromoteHeaders(FromHeader), each [CONTRACT_ID] <> null),
    Clean = Table.TransformColumns(Rows, {
        {"DATE_SIGN", each try DateTime.FromText(Text.AfterDelimiter(_, ", "), [Format="dd MMM yyyy HH:mm:ss",Culture="en-US"]) otherwise null, type nullable datetime},
        {"TENOR", each try Number.From(_) otherwise null, type nullable number},
        {"REQ_STATUS", each if _ = null then null else Text.Upper(Text.Trim(_)), type nullable text}
    }),
    Checked = if Table.IsDistinct(Clean, {"CONTRACT_ID"}) then Clean else error "Duplicate CONTRACT_ID: check request history"
in
    Checked
