-- Q3. Two peer groups. The DSM rank is nested in its area.
-- Stable presentation order does not break ties inside the ranking windows.
SELECT m.*,
       dense_rank() OVER (
           PARTITION BY month_start, area, dsm_code ORDER BY total_bonus DESC
       ) AS rank_in_dsm,
       dense_rank() OVER (
           PARTITION BY month_start, area ORDER BY total_bonus DESC
       ) AS rank_in_area
FROM employee_month AS m
ORDER BY month_start, area, rank_in_area, dsm_code, ds_code;
