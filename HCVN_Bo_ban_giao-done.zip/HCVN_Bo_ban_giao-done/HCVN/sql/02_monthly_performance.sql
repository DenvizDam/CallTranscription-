-- Q2. All listed employees including zero-activity months.
SELECT * FROM employee_month ORDER BY month_start, area, dsm_code, ds_code;
