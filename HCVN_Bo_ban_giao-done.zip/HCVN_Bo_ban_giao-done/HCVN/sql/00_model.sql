-- SQLite 3.25+. Input timestamps are ISO 8601 local timestamps in one time zone.
CREATE TABLE employees (
    ds_code TEXT PRIMARY KEY NOT NULL, ds_name TEXT NOT NULL,
    dsm_code TEXT NOT NULL, dsm_name TEXT NOT NULL, area TEXT NOT NULL
);
CREATE TABLE contracts (
    con_number TEXT PRIMARY KEY NOT NULL, cuid TEXT NOT NULL,
    dscode_apply TEXT, dscode_sign TEXT, dscode_cancel TEXT,
    date_apply TEXT NOT NULL, date_sign TEXT, credit_amount INTEGER, status TEXT NOT NULL,
    date_cancel TEXT -- optional authoritative event timestamp, absent in the source image
);
CREATE INDEX ix_signed ON contracts(date_sign, dscode_sign) WHERE status = 'Active';
CREATE INDEX ix_cancel ON contracts(cuid, dscode_cancel, coalesce(date_cancel, date_apply))
WHERE status = 'Cancelled';

-- One row per signed contract. Filtering by date_sign in consumers preserves index use.
CREATE VIEW contract_bonus AS
SELECT s.con_number, s.cuid, s.date_sign, s.dscode_sign AS ds_code, e.ds_name,
       CASE WHEN EXISTS (
           SELECT 1
           FROM contracts AS p
           WHERE p.status = 'Cancelled'
             AND p.cuid = s.cuid
             AND p.dscode_cancel = s.dscode_apply
             AND p.con_number <> s.con_number
             AND coalesce(p.date_cancel, p.date_apply) >= datetime(s.date_sign, '-3 days')
             AND coalesce(p.date_cancel, p.date_apply) < datetime(s.date_sign)
       ) THEN 50000 ELSE 100000 END AS bonus
FROM contracts AS s
JOIN employees AS e ON e.ds_code = s.dscode_sign
WHERE s.status = 'Active' AND s.date_sign IS NOT NULL
  AND s.date_sign <> '3000-01-01 00:00:00';

-- Aggregate first, then fill the 24-month roster matrix.
CREATE VIEW employee_month AS
WITH RECURSIVE months(month_start) AS (
    VALUES ('2025-01-01')
    UNION ALL
    SELECT date(month_start, '+1 month') FROM months WHERE month_start < '2026-12-01'
), totals AS (
    SELECT date(date_sign, 'start of month') AS month_start, ds_code,
           count(*) AS signed_contracts, sum(bonus) AS total_bonus
    FROM contract_bonus
    WHERE date_sign >= '2025-01-01' AND date_sign < '2027-01-01'
    GROUP BY date(date_sign, 'start of month'), ds_code
)
SELECT m.month_start, e.ds_code, e.ds_name, e.dsm_code, e.dsm_name, e.area,
       coalesce(t.signed_contracts, 0) AS signed_contracts,
       coalesce(t.total_bonus, 0) AS total_bonus
FROM months AS m CROSS JOIN employees AS e
LEFT JOIN totals AS t ON t.month_start = m.month_start AND t.ds_code = e.ds_code;
