-- Q1. One row per employee who signed an eligible June contract.
SELECT b.ds_code, b.ds_name, count(*) AS signed_contracts,
       sum(b.bonus) AS total_bonus
FROM contract_bonus AS b
WHERE b.date_sign >= '2025-06-01' AND b.date_sign < '2025-07-01'
GROUP BY b.ds_code, b.ds_name
ORDER BY total_bonus DESC, b.ds_code;
