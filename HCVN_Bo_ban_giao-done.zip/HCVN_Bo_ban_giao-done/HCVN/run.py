"""Rebuild SQL and retention outputs locally with Python 3.9+ (standard library)."""
import calendar
import csv
import sqlite3
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

def source(name):
    with (ROOT / "data" / (name + ".csv")).open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def save(name, rows):
    rows = list(rows)
    with (RESULTS / (name + ".csv")).open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)

def db():
    con = sqlite3.connect(":memory:")
    con.row_factory = sqlite3.Row
    con.executescript((ROOT / "sql/00_model.sql").read_text())
    for table in ("employees", "contracts"):
        data = source(table)
        cols = list(data[0])
        con.executemany(f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",
                        [[r[c] or None for c in cols] for r in data])
    return con

def query(con, n):
    sql = next((ROOT / "sql").glob(f"{n:02}_*.sql")).read_text()
    return [dict(row) for row in con.execute(sql)]

def shift_month(d, months):
    index = d.year * 12 + d.month - 1 + months
    year, m0 = divmod(index, 12)
    return date(year, m0 + 1, min(d.day, calendar.monthrange(year, m0 + 1)[1]))

def midpoint(signed, tenor):
    start = shift_month(signed, tenor // 2)
    if tenor % 2 == 0:
        return start
    end = shift_month(signed, tenor // 2 + 1)
    return start + timedelta(days=(end - start).days // 2)

def decision(call, signed, tenor, status):
    if not call or not signed or not tenor or tenor <= 0 or call < signed or status not in ("CANCELLED", "EXPIRE", "EXECUTED"):
        return None, None, "Review"
    gate = status in ("CANCELLED", "EXPIRE")
    mid = midpoint(signed, tenor)
    timing = None if call == mid else call > mid
    if not gate or timing is False:
        outcome = "Fail"
    elif timing is None:
        outcome = "Review"
    else:
        outcome = "Success"
    return gate, timing, outcome

def unique(rows, key):
    mapped = {r[key]: r for r in rows}
    if "" in mapped or len(mapped) != len(rows):
        raise ValueError(f"Missing or duplicate {key}")
    return mapped

def retention():
    calls = unique(source("calls"), "CALL_ID")
    loans = unique(source("loan_requests"), "CONTRACT_ID")
    agents = unique(source("agents"), "Employee ID")
    records = []
    for c in calls.values():
        loan = loans.get(c["CONTRACT_ID"], {})
        agent = agents.get(c["EMPLOYEE"], {})
        sign = datetime.strptime(loan["DATE_SIGN"].split(", ")[1], "%d %b %Y %H:%M:%S").date() if loan else None
        tenor = int(loan["TENOR"]) if loan else None
        call = date.fromisoformat(c["CALL_DATE"])
        gate, timing, score = decision(call, sign, tenor, loan.get("REQ_STATUS"))
        records.append({**c, "TEAM":agent.get("Team"), "OFFER_TYPE":"" if c["OFFER_TYPE"]=="NULL" else c["OFFER_TYPE"],
                        "REQ_STATUS":loan.get("REQ_STATUS"), "TENOR":tenor, "SIGN_DATE":sign,
                        "MIDPOINT_DAY":midpoint(sign,tenor) if sign and tenor and tenor>0 else None,
                        "STATUS_OK":gate,"AFTER_HALF":timing,"OUTCOME":score})
    return records

def edge_tests():
    con = db()
    def put(num, cuid, apply, signer, canceler, applied, signed, status, cancel_time=None):
        con.execute("INSERT INTO contracts VALUES (?,?,?,?,?,?,?,0,?,?)",
                    (num, cuid, apply, signer, canceler, applied, signed, status, cancel_time))
    # All edge cases below are isolated from the supplied records and never exported.
    for i, (hours, actor, customer, expected) in enumerate([
        (72,"0046345","u",50000),(72+1/3600,"0046345","u",100000),
        (0,"0046345","u",100000),(-1,"0046345","u",100000),
        (1,"113916","u",100000),(1,"0046345","other",100000)]):
        key=f"edge{i}"
        ts=datetime(2025,6,1,0,5)
        previous=(ts-timedelta(hours=hours)).isoformat(" ")
        put(key+"p",key+customer,"other",None,actor,previous,None,"Cancelled")
        put(key,key+"u","0046345","113916",None,ts.isoformat(" "),ts.isoformat(" "),"Active")
        assert con.execute("SELECT bonus FROM contract_bonus WHERE con_number=?",(key,)).fetchone()[0]==expected
    put("twoA","repeat","X",None,"0046345","2025-05-25",None,"Cancelled","2025-05-31 10:00:00")
    put("twoB","repeat","X",None,"0046345","2025-05-31 11:00:00",None,"Cancelled")
    put("twoS","repeat","0046345","113916",None,"2025-06-01 08:00:00","2025-06-01 09:00:00","Active")
    assert tuple(con.execute("SELECT count(*),sum(bonus) FROM contract_bonus WHERE con_number='twoS'").fetchone())==(1,50000)
    con.execute("UPDATE contracts SET date_cancel='2025-06-04 00:00:00' WHERE con_number IN ('twoA','twoB')")
    assert con.execute("SELECT bonus FROM contract_bonus WHERE con_number='twoS'").fetchone()[0]==100000
    con.close()
    s=date(2024,1,31)
    assert midpoint(s,3)==date(2024,3,15)
    assert decision(date(2024,3,15),s,3,"EXPIRE")[2]=="Review"
    assert decision(date(2024,3,16),s,3,"EXPIRE")[2]=="Success"
    assert decision(date(2024,3,14),s,3,"EXPIRE")[2]=="Fail"
    assert decision(date(2024,3,16),s,3,"EXECUTED")[2]=="Fail"
    assert decision(date(2024,3,16),s,None,"EXPIRE")[2]=="Review"

def main():
    RESULTS.mkdir(exist_ok=True)
    con=db()
    june, monthly, ranks = [query(con,n) for n in (1,2,3)]
    audit=[dict(r) for r in con.execute("""SELECT c.con_number,c.cuid,c.dscode_apply,c.dscode_sign,c.date_sign,c.status,b.ds_code,b.bonus,
        CASE WHEN c.status='Active' THEN (
          SELECT count(*) FROM contracts p WHERE p.status='Cancelled' AND p.con_number<>c.con_number
            AND p.cuid=c.cuid AND p.dscode_cancel=c.dscode_apply
        ) END AS matching_cancellations_any_time,
        CASE WHEN c.status <> 'Active' THEN c.status
             WHEN c.date_sign < '2025-01-01' OR c.date_sign >= '2027-01-01' THEN 'Outside period'
             WHEN e.ds_code IS NULL THEN 'Signer outside employee roster'
             ELSE 'Included' END AS disposition
        FROM contracts c LEFT JOIN contract_bonus b ON b.con_number=c.con_number AND b.date_sign>='2025-01-01' AND b.date_sign<'2027-01-01'
        LEFT JOIN employees e ON e.ds_code=c.dscode_sign ORDER BY c.rowid""")]
    # Independent of timestamp or proxy: check all cancellations, across all years.
    june_cases = [r for r in audit if r["status"]=="Active" and r["date_sign"].startswith("2025-06-")]
    assert len(june_cases)==7
    assert [r["con_number"] for r in june_cases if r["matching_cancellations_any_time"]]==["342780575"]
    assert all(r["matching_cancellations_any_time"]==0 for r in june_cases if r["ds_code"])
    assert len(audit)==18 and len(source("employees"))==15
    assert {r["ds_code"]:r["total_bonus"] for r in june}==dict.fromkeys(("0046345","0031282","113916","0046524"),100000)
    assert len(monthly)==len(ranks)==360 and sum(r["total_bonus"] for r in monthly)==600000
    expected={"335453263","342718554","343115240","342961572","342806676","343025279"}
    assert {r["con_number"] for r in audit if r["disposition"]=="Included"}==expected
    assert Counter(r["month_start"] for r in monthly if r["signed_contracts"])=={"2025-01-01":1,"2025-05-01":1,"2025-06-01":4}
    for r in ranks:
        peers=[p for p in monthly if (p["month_start"],p["area"])==(r["month_start"],r["area"])]
        for key, group in (("rank_in_area",peers),("rank_in_dsm",[p for p in peers if p["dsm_code"]==r["dsm_code"]])):
            assert r[key]==1+len({p["total_bonus"] for p in group if p["total_bonus"]>r["total_bonus"]})
    pbi=retention()
    expected_timing=[True,True,True,False,True,False,False,False,False,True]
    assert [r["AFTER_HALF"] for r in pbi]==expected_timing
    assert [r["CONTRACT_ID"] for r in pbi if r["OUTCOME"]=="Success"]==["CT001","CT005"]
    assert sum(r["STATUS_OK"] for r in pbi)==6 and len(pbi)==10
    assert len({r["CALL_ID"] for r in pbi})==len({r["CONTRACT_ID"] for r in pbi})==10
    assert all(r["TEAM"] and r["OUTCOME"]!="Review" for r in pbi)
    assert Counter((r["STATUS_OK"],r["AFTER_HALF"]) for r in pbi)=={
        (True,True):2,(True,False):4,(False,True):3,(False,False):1}
    edge_tests()
    for name,rows in [("01_june_bonus",june),("02_monthly_performance",monthly),("03_monthly_rank",ranks),
                      ("contracts_audit",audit),("retention_audit",pbi)]: save(name,rows)
    print("PASS | 18 contracts | 15 employees | 360 monthly ranks | June 400,000 | all months 600,000")
    print("PASS | 10 calls | 6 status qualified | 5 after midpoint | 2 successful | edge checks passed")

if __name__=="__main__":
    main()
