# S2T / NER Root Cause Analysis — Python Only (V6)

Công cụ phân loại nguyên nhân lỗi S2T / NER trên dữ liệu Call Center. **Không sử dụng LLM, không cần `.env`, không cần API key.** Được thiết kế cho Python 3.11 / Conda, chạy hoàn toàn offline.

## 1. Nguyên tắc bắt buộc

1. Giữ nguyên **toàn bộ dòng, thứ tự dòng và các cột gốc**, bao gồm các cột không dùng đến. Chỉ bổ sung 5 cột `RCA_*` vào **file đầu ra mới**. Giá trị đọc/ghi lại theo pandas, vì vậy kiểu dữ liệu, định dạng ô Excel, công thức và style gốc **không được bảo đảm giữ nguyên**; nếu cần giữ định dạng workbook 100%, nên xuất bảng kết quả riêng để ghép vào workbook gốc bằng Excel.
2. Chỉ xử lý dòng có `Label = good` (không phân biệt chữ hoa/thường, loại khoảng trắng hai đầu). Dòng khác vẫn xuất ra, `RCA_Label = Not Evaluated`.
3. **NER chỉ được đánh giá bằng `Entities Extracted` so với `Transcript (AI)`.** `TextScript` không được sử dụng để kết luận NER sai.
4. **Không sửa/chuyển đổi `Entities Extracted`.** Chỉ bỏ hậu tố điểm `(0.0)`, `(1.0)`, ... *trong bản copy để phân tích*; ô Excel gốc giữ nguyên.
5. Entity có tên kết thúc bằng `AMOUNT` bắt buộc là **chuỗi chữ số nguyên không âm không dấu cách** (ví dụ `250000000`). `FACEAMOUNT: 250 triệu` là NER sai **định dạng**, dù transcript ghi `250 triệu`.
6. Transcript được phép so khớp theo số: `250 triệu` ≡ `250000000`; `22 triệu 100 nghìn` ≡ `22100000`. Giá trị NER không được chuyển từ chữ thành số.
7. **Không ép `Both Phase`** chỉ vì hai threshold đều dưới 1. So khớp giá trị không đồng nghĩa với đúng loại/ngữ cảnh; dữ liệu chưa đủ -> `Need Review`.

## 2. Các cột đầu vào

Bắt buộc: `Label`, `Transcript (AI)`, `Transcript Threshold S2T`, `Transcript Threshold NER`, `Entities Extracted`.

Khuyến nghị: `Entities To Extract` — *phải chứa danh sách tên entity*, ví dụ `FACEAMOUNT, SUNDRYAMOUNT` hoặc `["FACEAMOUNT","SUNDRYAMOUNT"]`. Nếu đây là văn bản mô tả tự do, chương trình sẽ không tự suy diễn; có thể dẫn đến `Need Review`. Các cột khác đều giữ lại.

`Entities Extracted` hỗ trợ multiline:

```text
FACEAMOUNT: 250000000 (0.0)
PREMIUMTERM: 53 (1.0)
SUNDRYAMOUNT: 22100000 (1.0)
PREMIUMMODE: năm (1.0)
```

Đồng thời hỗ trợ JSON object/list dạng đơn giản. Chỉ điểm đánh giá hậu tố được bỏ qua khi parse.

## 3. Phân loại

| S2T | NER | Điều kiện | RCA_Label |
| --- | --- | --- | --- |
| =1 | =1 | Cả hai đạt mốc | `No Error` |
| =1 | <1 | S2T đạt mốc | `NER` |
| <1 | =1 | NER đạt mốc | `S2T` |
| <1 | <1 | NER vi phạm format AMOUNT rõ ràng | `Both Phase` |
| <1 | <1 | Tất cả entity cần thiết hiện diện; khớp format, giá trị và có dấu hiệu ngữ cảnh cục bộ | `S2T` |
| <1 | <1 | Không chứng minh được một nhánh chắc chắn | `Need Review` |

**Quan trọng:** Đây là bộ quy tắc bảo thủ. Chương trình không thể xác nhận chắc chắn mọi ngữ cảnh tiếng Việt, các số viết bằng chữ hoàn toàn, lựa chọn sai giữa nhiều số tương đương, hay entity bị thiếu khi `Entities To Extract` không có cấu trúc. Các trường hợp này phải được rà soát. Không cam kết tự phân loại đúng toàn bộ dataset.

## 4. Output: chỉ 5 cột mới

| Cột | Công dụng |
| --- | --- |
| `RCA_Label` | `S2T`, `NER`, `Both Phase`, `No Error`, `Need Review`, `Not Evaluated` |
| `RCA_Reason` | Giải thích ngắn gọn, dựa trên quy tắc |
| `RCA_NER_Check` | `Supported`, `Incorrect`, `Value matched`, `Unverified`, `Threshold flag`, `Not checked`... |
| `RCA_Review` | `Yes` hoặc `No`; có cần rà soát thủ công không |
| `RCA_Entity_Details` | JSON của từng entity: `format_valid`, `value_found`, `match_mode`, `context`, `status`; phục vụ audit/debug. Có thể ẩn cột này trong Excel khi báo cáo. |

**Không có** `RCA_LLM_Status`, `RCA_LLM_Label`, `RCA_Confidence`, `RCA_Candidate`, vì không còn LLM hay kết luận confidence giả.

## 5. Cài trên Ubuntu (Conda)

```bash
conda create -n s2t_rca python=3.11 -y
conda activate s2t_rca
python -m pip install -r requirements.txt
python -m pip install -e . --no-build-isolation
```

Hoặc `conda env create -f environment.yml` (tạo môi trường mới từ file). Chỉ cần chọn **một** cách.

## 6. Chạy

```bash
python -m rootcause.cli --input input/dataset.xlsx --output output/result.xlsx
```

Chọn sheet theo tên:

```bash
python -m rootcause.cli --input input/dataset.xlsx --sheet 'Sheet1' --output output/result.xlsx
```

Chạy CSV:

```bash
python -m rootcause.cli --input examples/sample.csv --output output/sample_result.csv
```

Test:

```bash
python -m pytest -q
```

## 7. Cấu trúc

```text
s2t-ner-python-only/
├── src/rootcause/
│   ├── matching.py        # parse entity, so khớp số lượng và format
│   ├── engine.py          # quyết định RCA và kiểm tra ngữ cảnh
│   └── cli.py             # đọc/ghi Excel/CSV, giữ mọi hàng/cột
├── tests/                 # unit tests + bảo toàn cột/dòng
├── examples/sample.csv
├── environment.yml
├── requirements.txt
├── pyproject.toml
└── .github/workflows/tests.yml
```

## 8. Giới hạn và lưu ý thực tế

- Logic ngữ cảnh dùng bảng `ROLE_HINTS` trong `matching.py`, cần hiệu chỉnh theo chính xác các entity/mẫu câu thực tế của công ty. Từ khóa ở gần giá trị chỉ là **bằng chứng sơ bộ**, không phải bằng chứng đầy đủ trong mọi câu thoại.
- Nếu muốn xét thiếu entity đúng, cần danh sách thực thể mong đợi có cấu trúc. Nếu cột `Entities To Extract` chỉ là mô tả, không thể tự đánh dấu thiếu entity một cách đáng tin cậy.
- Nếu muốn kiểm tra S2T dựa trên từng số tiền/mã liên quan tới entity thay vì cả cuộc gọi, cần thêm nhãn đánh giá cấp entity. Hai threshold hiện tại phản ánh đánh giá tổng thể.
- File có thông tin khách hàng: không commit dataset thật, không đưa dữ liệu nhạy cảm vào issue GitHub.
- Bản này đã có unit tests và smoke test dữ liệu mẫu, **chưa kiểm thử độ chính xác trên dataset thực tế**.
