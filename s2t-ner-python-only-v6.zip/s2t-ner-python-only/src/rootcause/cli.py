import argparse
from pathlib import Path
import pandas as pd
from .engine import classify

REQUIRED=['Label','Transcript (AI)','Transcript Threshold S2T','Transcript Threshold NER','Entities Extracted']
ADDED=['RCA_Label','RCA_Reason','RCA_NER_Check','RCA_Review','RCA_Entity_Details']

def run(input_path,output_path,sheet=0):
    src=Path(input_path); dst=Path(output_path)
    if src.suffix.lower() in ('.xlsx','.xlsm'):
        df=pd.read_excel(src,sheet_name=sheet,dtype=object)
    elif src.suffix.lower()=='.csv':
        df=pd.read_csv(src,dtype=object,keep_default_na=False,encoding='utf-8-sig')
    else: raise ValueError('Chỉ hỗ trợ .xlsx/.xlsm/.csv')
    absent=[x for x in REQUIRED if x not in df.columns]
    if absent: raise ValueError('Thiếu cột: '+', '.join(absent))
    collisions=[x for x in ADDED if x in df.columns]
    if collisions: raise ValueError('Cột output đã tồn tại trong input: '+', '.join(collisions))
    results=[]
    for _,row in df.iterrows():
        if str(row['Label']).strip().casefold()!='good':
            results.append(['Not Evaluated','Label khác good','Not Evaluated','No',''])
            continue
        r=classify(row['Transcript Threshold S2T'],row['Transcript Threshold NER'],row['Transcript (AI)'],row['Entities Extracted'],row.get('Entities To Extract'))
        results.append([r.label,r.reason,r.ner_check,r.review,r.entity_checks])
    out=df.copy()
    for i,name in enumerate(ADDED):out[name]=[r[i] for r in results]
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.suffix.lower()=='.xlsx': out.to_excel(dst,index=False)
    elif dst.suffix.lower()=='.csv': out.to_csv(dst,index=False,encoding='utf-8-sig')
    else:raise ValueError('Output phải là .xlsx hoặc .csv')
    print(f'Input: {len(df)} rows; Output: {len(out)} rows; Saved: {dst}')
    print(out['RCA_Label'].value_counts(dropna=False).to_string())

def main():
    p=argparse.ArgumentParser(description='S2T/NER Root Cause Analysis - Python Only')
    p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p.add_argument('--sheet',default='0',help='Excel sheet name or 0-based index')
    a=p.parse_args();sheet=int(a.sheet) if a.sheet.isdecimal() else a.sheet
    run(a.input,a.output,sheet)
if __name__=='__main__':main()
