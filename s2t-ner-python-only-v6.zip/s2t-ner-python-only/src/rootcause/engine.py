"""Deterministic RCA. NER is assessed against AI transcript, NEVER ground truth."""
from __future__ import annotations
import json
import re
from dataclasses import dataclass
from collections import Counter
from .matching import (score, missing, normalize, parse_entities, detail_matches,
                       is_amount_entity, ROLE_HINTS, amount_mentions)

@dataclass
class Result:
    label: str
    reason: str
    ner_check: str
    entity_checks: str
    review: str


def expected_types(raw):
    """Parse expected entity NAMES only. Unknown/unstructured => None."""
    if missing(raw):
        return None
    if isinstance(raw, str):
        obj = raw.strip()
        if obj.startswith(('[','{')):
            try:
                parsed = json.loads(obj)
                if isinstance(parsed, dict): return [str(k).upper() for k in parsed]
                if isinstance(parsed, list):
                    out=[]
                    for x in parsed:
                        if isinstance(x,str): out.append(x.upper())
                        elif isinstance(x,dict) and ('type' in x or 'name' in x): out.append(str(x.get('type',x.get('name'))).upper())
                        else: return None
                    return out
            except ValueError: pass
        # only names, not free-form natural language
        parts = re.split(r'[,;\n]+', obj)
        if parts and all(re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', p.strip()) for p in parts):
            return [p.strip().upper() for p in parts]
        return None
    return None


def context_evidence(entry, transcript):
    """Local proximity clue only. Never treats a generic keyword anywhere as proof."""
    typ = str(entry['type']).upper()
    hints = ROLE_HINTS.get(typ)
    if not hints: return 'unknown'
    t = normalize(transcript)
    val = normalize(entry['value'])
    matches=[]
    if is_amount_entity(typ) and re.fullmatch(r'\d+', val):
        # Recover transcript numeric spans with units; only safe when amount unambiguous.
        import decimal
        rx = re.compile(r'(?<!\w)\d+(?:[.,]\d+)?\s*(?:tỷ|tỉ|triệu|nghìn|ngàn)(?:\s+\d+(?:[.,]\d+)?\s*(?:triệu|nghìn|ngàn))?')
        from .matching import amount_mentions
        for m in rx.finditer(t):
            if int(val) in amount_mentions(m.group(0)):
                matches.append((m.start(),m.end()))
        for m in re.finditer(r'(?<!\w)'+re.escape(val)+r'(?!\w)',t):
            matches.append((m.start(),m.end()))
    else:
        matches=[(m.start(),m.end()) for m in re.finditer(r'(?<!\w)'+re.escape(val)+r'(?!\w)',t)]
    if not matches: return 'unknown'
    # Look behind the mention rather than anywhere in call to reduce false label matches.
    for begin,end in matches:
        preceding=t[max(0,begin-90):begin]
        if any(h in preceding for h in hints): return 'supported'
    return 'unknown'


def classify(s2t, ner, transcript, extracted, to_extract=None):
    s,n=score(s2t),score(ner)
    if s is None or n is None:
        return Result('Need Review','Threshold không hợp lệ hoặc bị thiếu','Unknown','[]','Yes')
    if s==1 and n==1:
        return Result('No Error','Cả hai threshold đều đạt mốc 1','Not checked','[]','No')
    if s==1 and n<1:
        return Result('NER','S2T đạt mốc; NER dưới mốc','Threshold flag','[]','No')
    if s<1 and n==1:
        return Result('S2T','S2T dưới mốc; NER đạt mốc','Threshold flag','[]','No')
    if missing(transcript):
        return Result('Need Review','Thiếu Transcript (AI)','Unknown','[]','Yes')
    entries,valid=parse_entities(extracted)
    if not valid or not entries:
        return Result('Need Review','Không đọc được Entities Extracted hoặc danh sách rỗng','Unknown','[]','Yes')
    checks=detail_matches(entries,transcript)
    expected=expected_types(to_extract)
    observed=Counter(str(e['type']).upper() for e in entries)
    missing_types=[]
    if expected is not None:
        required=Counter(expected)
        missing_types=list((required-observed).elements())
    for e,c in zip(entries,checks):
        c['context']=context_evidence(e,transcript)
        c['status']=('INVALID_FORMAT' if not c['format_valid'] else
                     'VALUE_MATCH' if c['value_found'] else 'UNVERIFIED_VALUE')
    debug=json.dumps(checks,ensure_ascii=False)
    invalid=[c['type'] for c in checks if not c['format_valid']]
    if invalid:
        return Result('Both Phase','S2T dưới mốc; NER sai định dạng AMOUNT: '+', '.join(invalid),'Incorrect',debug,'No')
    if missing_types:
        # Missing requested type is not necessarily an NER error unless transcript contains it.
        return Result('Need Review','Thiếu entity yêu cầu: '+', '.join(missing_types)+'; chưa xác minh transcript có chứa hay không','Unverified',debug,'Yes')
    nonmatch=[c['type'] for c in checks if not c['value_found']]
    if nonmatch:
        return Result('Need Review','Giá trị entity chưa đối chiếu được với transcript: '+', '.join(nonmatch),'Unverified',debug,'Yes')
    # Exact value agreement is NOT sufficient for correct NER type/context.
    unknown=[c['type'] for c in checks if c['context']!='supported']
    if unknown:
        return Result('Need Review','Giá trị đều khớp transcript nhưng chưa xác minh được ngữ cảnh: '+', '.join(unknown),'Value matched',debug,'Yes')
    if expected is None:
        return Result('Need Review','Entity hiện có khớp giá trị và ngữ cảnh; chưa kiểm chứng danh sách entity bắt buộc','Value and context supported',debug,'Yes')
    return Result('S2T','S2T dưới mốc; các entity bắt buộc hiện diện, đúng định dạng, giá trị và có bằng chứng ngữ cảnh trong transcript','Supported',debug,'No')
