import pandas as pd
from rootcause.cli import run

def test_keep_rows_columns(tmp_path):
    source=tmp_path/'raw.xlsx'; target=tmp_path/'result.xlsx'
    df=pd.DataFrame({'QID':['a','b'],'Unused':['x','y'],'Label':['good','bad'],'Transcript (AI)':['số tiền bảo hiểm 250 triệu',''], 'Transcript Threshold S2T':[.8,1], 'Transcript Threshold NER':[.8,1], 'Entities Extracted':['FACEAMOUNT: 250000000',''],'Entities To Extract':['FACEAMOUNT','']})
    df.to_excel(source,index=False)
    run(source,target)
    result=pd.read_excel(target)
    assert len(result)==2
    assert result['Unused'].tolist()==['x','y']
    assert result.loc[0,'RCA_Label']=='S2T'
    assert result.loc[1,'RCA_Label']=='Not Evaluated'
