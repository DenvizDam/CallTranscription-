from rootcause.engine import classify
from rootcause.matching import parse_entities, amount_mentions

def test_no_error():assert classify(1,1,'','').label=='No Error'
def test_s2t():assert classify(.8,1,'','').label=='S2T'
def test_ner():assert classify(1,.5,'','').label=='NER'
def test_amount():assert 22100000 in amount_mentions('phí dự tính 22 triệu 100 nghìn đồng')
def test_keep_raw():
    e,ok=parse_entities('FACEAMOUNT: 250 triệu (0.0)');assert ok and e[0]['value']=='250 triệu'
def test_format_error():assert classify(.8,.8,'số tiền bảo hiểm 250 triệu','FACEAMOUNT: 250 triệu').label=='Both Phase'
def test_unknown_context():assert classify(.8,.8,'250 triệu','FACEAMOUNT: 250000000').label=='Need Review'
def test_context_valid():
    r=classify(.8,.8,'số tiền bảo hiểm 250 triệu đồng','FACEAMOUNT: 250000000','FACEAMOUNT')
    assert r.label=='S2T',r
