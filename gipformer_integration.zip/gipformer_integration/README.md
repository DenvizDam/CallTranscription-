# Add Gipformer 1.5 to CallCSPro

1. Copy `models/gipformer.py` into existing `CallCSPro/models/`.
2. Merge the registry entry from `models/registry.py` (or replace only if unchanged from prior CallCSPro version).
3. Append the Gipformer block from `configs/models_gipformer_snippet.yaml` into the existing `configs/models.yaml`; keep existing models untouched.
4. Install `sherpa-onnx`, `sherpa-onnx-core`, and `huggingface_hub` in your benchmark environment.
5. Download checkpoint ONNX files from Hugging Face to `/home/dtphat/projects/Gipformer-1.5`.
6. Run `python benchmark.py --model gipformer --limit 3`, then `--limit 0`.

Suggested download:

```bash
mkdir -p /home/dtphat/projects/Gipformer-1.5
hf download g-group-ai-lab/gipformer1.5-68M-rnnt \
  encoder.int8.onnx decoder.int8.onnx joiner.int8.onnx tokens.txt \
  --local-dir /home/dtphat/projects/Gipformer-1.5
```

For GPU, change `provider: cpu` to `provider: cuda` only after installing a CUDA-enabled sherpa-onnx runtime and verifying its providers. CPU is a safe first test, and you should record the device when comparing RTF.

If `decoding_method: modified_beam_search` is rejected by your installed sherpa-onnx version, test `greedy_search`; report the change in run metadata.

This package has been syntax-checked, but not inference-tested on your checkpoint/hardware. The checkpoint's MIT license is declared on its Hugging Face model card; review company usage requirements.
