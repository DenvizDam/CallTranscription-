"""Gipformer 1.5 ONNX adapter for CallCSPro modular benchmark.
Expected input: mono float32 waveform, 16 kHz (prepared by benchmark.py).
"""
from pathlib import Path
import numpy as np
import sherpa_onnx


class GipformerAdapter:
    def __init__(self, cfg):
        self.sr = int(cfg.get("sample_rate", 16000))
        if self.sr != 16000:
            raise ValueError("Gipformer 1.5 ONNX requires 16000 Hz")

        folder = Path(cfg["checkpoint"]).expanduser()
        quantize = cfg.get("quantize", "int8").lower()
        if quantize not in ("int8", "fp32"):
            raise ValueError("quantize must be 'int8' or 'fp32'")
        suffix = ".int8.onnx" if quantize == "int8" else ".onnx"
        names = {
            "encoder": cfg.get("encoder", f"encoder{suffix}"),
            "decoder": cfg.get("decoder", f"decoder{suffix}"),
            "joiner": cfg.get("joiner", f"joiner{suffix}"),
            "tokens": cfg.get("tokens", "tokens.txt"),
        }
        paths = {key: folder / name for key, name in names.items()}
        missing = [str(p) for p in paths.values() if not p.is_file()]
        if missing:
            raise FileNotFoundError("Missing Gipformer model files:\n" + "\n".join(missing))

        self.recognizer = sherpa_onnx.OfflineRecognizer.from_transducer(
            encoder=str(paths["encoder"]),
            decoder=str(paths["decoder"]),
            joiner=str(paths["joiner"]),
            tokens=str(paths["tokens"]),
            num_threads=int(cfg.get("num_threads", 4)),
            provider=str(cfg.get("provider", "cpu")),
            sample_rate=self.sr,
            feature_dim=80,
            decoding_method=cfg.get("decoding_method", "modified_beam_search"),
        )

    def transcribe(self, audio, sr=16000):
        if sr != self.sr:
            raise ValueError(f"Input is {sr} Hz, expected {self.sr} Hz")
        samples = np.asarray(audio, dtype=np.float32).reshape(-1)
        if samples.size == 0:
            return ""
        # Short fragments can fail in transducer encoder; pad rather than drop speech.
        min_samples = int(self.sr * 0.5)
        if samples.size < min_samples:
            samples = np.pad(samples, (0, min_samples - samples.size))
        stream = self.recognizer.create_stream()
        stream.accept_waveform(self.sr, samples)
        self.recognizer.decode_stream(stream)
        return stream.result.text.strip()
