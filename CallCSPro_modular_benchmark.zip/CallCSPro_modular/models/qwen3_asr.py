import torch

class Qwen3ASRAdapter:
    def __init__(self, cfg):
        try:
            from qwen_asr import Qwen3ASRModel
        except ImportError as exc:
            raise RuntimeError('Install qwen-asr (separate optional dependency)') from exc
        self.sr = 16000
        self.model = Qwen3ASRModel.from_pretrained(
            cfg['checkpoint'],
            dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
            device_map='cuda:0' if torch.cuda.is_available() else 'cpu',
            max_new_tokens=int(cfg.get('max_new_tokens', 512)),
        )

    def transcribe(self, audio, sr=16000):
        output = self.model.transcribe(audio=(audio, sr), language='Vietnamese', return_time_stamps=False)
        return output[0].text.strip()
