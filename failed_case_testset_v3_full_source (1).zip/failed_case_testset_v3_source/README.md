# Failed Case Test Set Builder — V3 (Full Payload + GT)

## What changed since V2

- Keeps `Quality == "Non-Perfect"` and `Label == "good"` in `DB Records`.
- Recursively searches all subfolders of `data_PRD/audios` and `data_PRD/payloads`, matching the **full QID**.
- Writes **flat sibling pairs** under `cases/`, named exactly:
  `<ProposalNo>_<QuestionNo>_<ScriptVersion>_<QID>.wav`
  `<ProposalNo>_<QuestionNo>_<ScriptVersion>_<QID>.json`
- JSON keeps **all original payload fields** (including `file_content`, `api`, `audio_format`, `correlation_id`, and any additional fields).
- Converts `metadata` JSON string into a JSON **object**, preserving all nested fields.
- Appends `gt` from the Excel `TextScript` column for the same QID, and `entities: {}`.
- Never modifies original Excel/WAV/payload files.
- Records missing/ambiguous values in `matching_report.csv`. Does not fabricate a ProposalNo/QuestionNo.

## Before running

Your Linux server has a mounted source tree at:

`/media/project_165/speechtotext/testset/data_PRD`

Place the Excel workbook next to `build_failed_case_testset.py` (as previously done). The script reads the worksheet's values, **not the Excel UI's current filters**.

**Naming source rules:**
- `ProposalNo`: Excel column `ProposalNo`, `Proposal No` or `Proposal Number` (and similar spellings); otherwise explicit top-level payload field, or single `PROPOSALNO` keyword VALUE if available.
- `QuestionNo`: Excel `QuestionNo` / `Question No` / `Question Number` / `QNo`; otherwise use `metadata.Keywords[*].questionNo` only when there is exactly one distinct question number.
- `ScriptVersion`: Excel `ScriptVersion` / `Script Version`, otherwise `payload.script_version`.
- `gt`: Required Excel column `TextScript`, `Text Script`, `Ground Truth` or `GT`.

If your actual header spelling is different, adjust `HEADER_ALIASES` at the top of the script. The code rejects missing or inconsistent naming/GT rather than guessing.

## Run on Linux server (single-line commands)

**Dry run** (no WAV/JSON case copying; writes a matching report):

```bash
python build_failed_case_testset.py --excel './20261008_db_analysis_Q3_2026.xlsx' --data-root '/media/project_165/speechtotext/testset/data_PRD' --output './failed_case_testset_v3' --sheet 'DB Records' --dry-run
```

**Generate files** (after checking `summary.json` and `matching_report.csv`):

```bash
python build_failed_case_testset.py --excel './20261008_db_analysis_Q3_2026.xlsx' --data-root '/media/project_165/speechtotext/testset/data_PRD' --output './failed_case_testset_v3' --sheet 'DB Records'
```

## Output example

```text
failed_case_testset_v3/
├── cases/
│   ├── EA01490901_2_I3_<QID>.wav
│   ├── EA01490901_2_I3_<QID>.json
│   └── ...
├── matching_report.csv
└── summary.json
```

The sample JSON structure looks like this (representative values, **not** actual data):

```json
{
  "audio_format": "m4a",
  "script_version": "I3",
  "metadata": {"Keywords": [{"entityName": "POLICYOWNER", "questionNo": 2}]},
  "correlation_id": "example",
  "file_content": "example-base64",
  "api": "sp2text-nrt-instant",
  "gt": "Ground truth text from the Excel TextScript cell",
  "entities": {}
}
```

**Note:** `audio_format` is copied unchanged from the payload even if the companion file is WAV.

## Reporting / errors

- `COMPLETE`, `DRY_RUN_READY`, `ALREADY_EXISTS`
- `MISSING_AUDIO`, `MISSING_PAYLOAD`, `MISSING_BOTH`, `DUPLICATE_FILES`
- `INVALID_CASE_DATA` for bad metadata, missing GT, missing/ambiguous name components, or a pre-existing `gt`/`entities` field that would be overwritten.

It will not overwrite existing output WAV/JSON files. Use the new `failed_case_testset_v3` output directory rather than reusing previous V1/V2 output. No third-party Python dependencies are needed.

## Important validation

After running:

```bash
cat ./failed_case_testset_v3/summary.json
find ./failed_case_testset_v3/cases -maxdepth 1 -type f -name '*.wav' | wc -l
find ./failed_case_testset_v3/cases -maxdepth 1 -type f -name '*.json' | wc -l
```

On sample data, syntax, full-payload preservation, JSON decoding, addition of `gt` and `{}` entities, and naming were tested. Real Excel column names and production payload variants have **not** yet been verified here.
