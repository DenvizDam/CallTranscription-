import os
import numpy as np
import torch

_VAD_MODEL = None

def speech_regions(audio, sr=16000, settings=None):
    global _VAD_MODEL
    from silero_vad import load_silero_vad, get_speech_timestamps
    if _VAD_MODEL is None:
        _VAD_MODEL = load_silero_vad(onnx=os.environ.get('VAD_BACKEND', 'torch') == 'onnx')
    settings = settings or {}
    timestamps = get_speech_timestamps(torch.from_numpy(audio), _VAD_MODEL, sampling_rate=sr,
        threshold=float(settings.get('threshold', 0.40)),
        min_speech_duration_ms=int(settings.get('min_speech_duration_ms', 150)),
        min_silence_duration_ms=int(settings.get('min_silence_duration_ms', 350)),
        speech_pad_ms=int(settings.get('speech_pad_ms', 250)))
    regions = []
    for item in timestamps:
        a, b = max(0, int(item['start'])), min(len(audio), int(item['end']))
        if b <= a:
            continue
        if regions and a <= regions[-1][1]:
            regions[-1][1] = max(regions[-1][1], b)
        else:
            regions.append([a, b])
    return regions


def concat_regions(audio, regions, sr=16000, gap_ms=200):
    if not regions:
        return np.empty(0, dtype=np.float32)
    parts = []
    gap = np.zeros(int(sr * gap_ms / 1000), dtype=np.float32)
    for i, (a, b) in enumerate(regions):
        if i:
            parts.append(gap)
        parts.append(audio[a:b])
    return np.concatenate(parts)
