import subprocess
from pathlib import Path
import numpy as np

SR = 16000

def load_audio(path, sr=SR):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    result = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(path), '-ac', '1', '-ar', str(sr), '-f', 'f32le', '-acodec', 'pcm_f32le', 'pipe:1'], capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', errors='replace'))
    audio = np.frombuffer(result.stdout, dtype='<f4').copy()
    if not audio.size or not np.isfinite(audio).all():
        raise ValueError(f'Invalid or empty audio: {path}')
    return audio
