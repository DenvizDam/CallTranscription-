def group_regions(regions, sr=16000, max_seconds=25):
    """Mirror V4 grouping on original timeline; preserve pauses inside groups."""
    max_samples = int(sr * max_seconds)
    if max_samples <= 0:
        raise ValueError('max_seconds must be positive')
    groups = []
    for original_start, original_end in regions:
        start = original_start
        while start < original_end:
            end = min(original_end, start + max_samples)
            if groups and end - groups[-1][0] <= max_samples:
                groups[-1][1] = end
            else:
                groups.append([start, end])
            start = end
    return groups
