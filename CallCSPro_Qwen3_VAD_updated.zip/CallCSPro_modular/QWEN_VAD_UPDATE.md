# Qwen3-ASR + VAD Segments update

This folder is the previous modular framework, with only `models/qwen3_asr.py` and `configs/models.yaml` changed for Qwen3-ASR. PhoWhisper, benchmark metrics and dataset remain unchanged.

## Apply to your existing project

1. Back up `configs/models.yaml` and `models/qwen3_asr.py`.
2. Copy the two updated files into your current CallCSPro project. **Do not overwrite the existing dataset or earlier results**.
3. If your Qwen3 checkpoint is local, replace `checkpoint` under `qwen3_asr` in `configs/models.yaml` with the actual model path.
4. Confirm packages: `pip install silero-vad qwen-asr` and FFmpeg installed.
5. From the project root:

```bash
python benchmark.py --model qwen3_asr --limit 3
python benchmark.py --model qwen3_asr --limit 0
```

The default mode is now `vad_segments` with a 20-second maximum grouping window. It uses Silero VAD and maintains chronological segment ordering. The `no_vad` control can still be run using:

```bash
python benchmark.py --model qwen3_asr --mode no_vad --limit 3
```

To try 15 seconds:

```bash
python benchmark.py --model qwen3_asr --mode vad_segments --segment-seconds 15 --limit 0
```

Results are written to `results/qwen3_asr/<timestamp>/` without overwriting older runs.

## OOM notes

Each segment is transcribed sequentially with inference-mode enabled. If CUDA runs out of memory, the adapter retries the *failing segment only* as two shorter halves, to a limited depth. This emergency split can reduce transcript accuracy near the new boundary. It is not a substitute for adequate VRAM. Other GPU processes may still cause OOM.

## Metric comparison

The previous Qwen3 run processed 79/80 recordings; compare on a matching successful set or re-run all 80 successfully. PhoWhisper's VAD duration settings are not assumed optimal for Qwen3; 20s is only a starting point.
