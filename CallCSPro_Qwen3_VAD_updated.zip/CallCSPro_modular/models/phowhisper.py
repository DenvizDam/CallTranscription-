import torch
from transformers import AutoProcessor, AutoModelForSpeechSeq2Seq

class PhoWhisperAdapter:
    def __init__(self, cfg):
        self.sr = 16000
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        checkpoint = cfg['checkpoint']
        self.processor = AutoProcessor.from_pretrained(checkpoint)
        self.model = AutoModelForSpeechSeq2Seq.from_pretrained(checkpoint).to(self.device).eval()
        self.decoding = dict(
            condition_on_prev_tokens=False,
            temperature=(0., .2, .4, .6, .8, 1.),
            compression_ratio_threshold=1.35,
            logprob_threshold=-1.0,
            no_speech_threshold=0.6,
        )

    @torch.inference_mode()
    def transcribe(self, audio, sr=16000):
        if not len(audio):
            return ''
        if sr != self.sr:
            raise ValueError(f'Expected {self.sr} Hz')
        features = self.processor(audio, sampling_rate=sr, return_tensors='pt', truncation=False,
                                  padding='longest', return_attention_mask=True)
        features = {k: v.to(self.device) for k, v in features.items()}
        long_form = len(audio) > 30 * sr
        kwargs = dict(self.decoding, return_timestamps=True) if long_form else {'return_timestamps': False}
        tokens = self.model.generate(**features, language='vi', task='transcribe', **kwargs)
        return self.processor.batch_decode(tokens, skip_special_tokens=True)[0].strip()
