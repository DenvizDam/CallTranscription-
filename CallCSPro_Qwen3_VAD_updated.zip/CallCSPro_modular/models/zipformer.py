from pathlib import Path
import sherpa_onnx

class ZipformerAdapter:
    """For sherpa-onnx Zipformer transducer checkpoints only."""
    def __init__(self, cfg):
        self.sr = 16000
        folder = Path(cfg['checkpoint'])
        for key in ('encoder', 'decoder', 'joiner', 'tokens'):
            if not (folder / cfg[key]).is_file():
                raise FileNotFoundError(folder / cfg[key])
        self.recognizer = sherpa_onnx.OfflineRecognizer.from_transducer(
            encoder=str(folder / cfg['encoder']),
            decoder=str(folder / cfg['decoder']),
            joiner=str(folder / cfg['joiner']),
            tokens=str(folder / cfg['tokens']),
            num_threads=int(cfg.get('num_threads', 4)),
            provider=cfg.get('provider', 'cpu'),
        )

    def transcribe(self, audio, sr=16000):
        stream = self.recognizer.create_stream()
        stream.accept_waveform(sr, audio)
        self.recognizer.decode_stream(stream)
        return stream.result.text.strip()
