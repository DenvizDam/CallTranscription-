from .phowhisper import PhoWhisperAdapter

class WhisperLargeAdapter(PhoWhisperAdapter):
    """Whisper-family adapter; config checkpoint may be openai/whisper-large-v3."""
    pass
