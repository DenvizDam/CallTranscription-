"""Qwen3-ASR adapter. Receives one PCM mono segment at 16 kHz.

The benchmark owns Silero VAD and segmentation. This adapter only runs ASR.
"""
import gc
import torch


class Qwen3ASRAdapter:
    def __init__(self, cfg):
        try:
            from qwen_asr import Qwen3ASRModel
        except ImportError as exc:
            raise RuntimeError('Install optional dependency: pip install qwen-asr') from exc

        self.sr = 16000
        self.cfg = dict(cfg)
        self.min_retry_seconds = float(cfg.get('oom_min_segment_seconds', 3.0))
        self.max_split_depth = int(cfg.get('oom_max_split_depth', 3))
        self.model = Qwen3ASRModel.from_pretrained(
            cfg['checkpoint'],
            dtype=torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported()
            else (torch.float16 if torch.cuda.is_available() else torch.float32),
            device_map='cuda:0' if torch.cuda.is_available() else 'cpu',
            max_new_tokens=int(cfg.get('max_new_tokens', 512)),
        )

    @torch.inference_mode()
    def _run_segment(self, audio, sr):
        result = self.model.transcribe(
            audio=(audio, sr),
            language='Vietnamese',
            return_time_stamps=False,
        )
        return result[0].text.strip()

    def transcribe(self, audio, sr=16000):
        if sr != self.sr:
            raise ValueError(f'Qwen3-ASR expects {self.sr} Hz, received {sr}')
        if not len(audio):
            return ''
        return self._transcribe_with_oom_retry(audio, sr, depth=0)

    def _transcribe_with_oom_retry(self, audio, sr, depth):
        try:
            return self._run_segment(audio, sr)
        except torch.OutOfMemoryError:
            # Free temporary GPU allocations; the model remains loaded.
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            seconds = len(audio) / sr
            if depth >= self.max_split_depth or seconds < 2 * self.min_retry_seconds:
                raise RuntimeError(
                    f'Qwen3-ASR CUDA OOM on {seconds:.1f}s segment after {depth} retries. '
                    'Try shorter segment_seconds, reduce other GPU users, or use CPU/offloading.'
                )
            mid = len(audio) // 2
            print(f'[QWEN OOM] Splitting {seconds:.1f}s segment into two shorter pieces')
            left = self._transcribe_with_oom_retry(audio[:mid].copy(), sr, depth + 1)
            right = self._transcribe_with_oom_retry(audio[mid:].copy(), sr, depth + 1)
            return ' '.join(x for x in (left, right) if x).strip()
