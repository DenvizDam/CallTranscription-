import tempfile
import os
import numpy as np
import soundfile as sf

class FastConformerAdapter:
    """For NVIDIA NeMo ASR checkpoints; check class support for chosen model."""
    def __init__(self, cfg):
        from nemo.collections.asr.models import ASRModel
        self.sr = 16000
        ckpt = cfg['checkpoint']
        if ckpt.endswith('.nemo'):
            self.model = ASRModel.restore_from(ckpt)
        else:
            self.model = ASRModel.from_pretrained(ckpt)
        self.model.eval()

    def transcribe(self, audio, sr=16000):
        if sr != self.sr:
            raise ValueError(f'Expected {self.sr} Hz')
        name = None
        try:
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
                name = f.name
            sf.write(name, np.asarray(audio, dtype=np.float32), sr)
            results = self.model.transcribe([name], batch_size=1)
            item = results[0]
            return (item.text if hasattr(item, 'text') else str(item)).strip()
        finally:
            if name and os.path.exists(name):
                os.unlink(name)
