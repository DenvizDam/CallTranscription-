from importlib import import_module

REGISTRY = {
    'phowhisper': ('models.phowhisper', 'PhoWhisperAdapter'),
    'whisper_large': ('models.whisper_large', 'WhisperLargeAdapter'),
    'qwen3_asr': ('models.qwen3_asr', 'Qwen3ASRAdapter'),
    'zipformer': ('models.zipformer', 'ZipformerAdapter'),
    'fastconformer': ('models.fastconformer', 'FastConformerAdapter'),
}

def load_model(name, config):
    if name not in REGISTRY:
        raise KeyError(f'Unknown model {name}. Available: {list(REGISTRY)}')
    module_name, class_name = REGISTRY[name]
    adapter = getattr(import_module(module_name), class_name)
    return adapter(config)
