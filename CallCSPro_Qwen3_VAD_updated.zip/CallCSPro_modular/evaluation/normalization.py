import re
import unicodedata

def normalize_text(text):
    text = unicodedata.normalize('NFC', str(text)).lower().strip()
    text = re.sub(r'[^\w\s]', ' ', text, flags=re.UNICODE)
    return re.sub(r'\s+', ' ', text).strip()
