from jiwer import wer, cer

def score(ref, pred):
    if not ref:
        raise ValueError('Empty normalized ground truth')
    return {'wer': wer(ref, pred), 'cer': cer(ref, pred)}

def summarize(rows):
    valid = [r for r in rows if r['status'] == 'OK']
    if not valid:
        return {'successful': 0, 'failed': len(rows)}
    refs = [r['normalized_ground_truth'] for r in valid]
    preds = [r['normalized_prediction'] for r in valid]
    audio_time = sum(float(r['duration_sec']) for r in valid)
    runtime = sum(float(r['processing_time_sec']) for r in valid)
    return {
        'successful': len(valid), 'failed': len(rows) - len(valid),
        'average_wer': sum(float(r['wer']) for r in valid) / len(valid),
        'average_cer': sum(float(r['cer']) for r in valid) / len(valid),
        'corpus_wer': wer(refs, preds), 'corpus_cer': cer(refs, preds),
        'rtf': runtime / audio_time if audio_time else None,
    }
