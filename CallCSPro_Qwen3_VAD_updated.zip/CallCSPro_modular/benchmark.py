import argparse
import csv
import json
import time
import traceback
from datetime import datetime
from pathlib import Path

import yaml

from models.registry import REGISTRY, load_model
from preprocessing.audio_loader import load_audio, SR
from preprocessing.vad import speech_regions, concat_regions
from preprocessing.segmentation import group_regions
from evaluation.normalization import normalize_text
from evaluation.metrics import score, summarize

ROOT = Path(__file__).resolve().parent
EXTENSIONS = {'.wav', '.gsm', '.mp3', '.flac', '.m4a'}
COLUMNS = ['model', 'mode', 'audio', 'ground_truth_file', 'ground_truth', 'prediction',
           'normalized_ground_truth', 'normalized_prediction', 'wer', 'cer',
           'duration_sec', 'processing_time_sec', 'rtf', 'vad_segments', 'groups',
           'speech_kept_ratio', 'status', 'error']


def get_pairs(audio_dir, gt_dir):
    if not audio_dir.is_dir() or not gt_dir.is_dir():
        raise FileNotFoundError(f'Dataset paths missing: {audio_dir}, {gt_dir}')
    audio_files = sorted(p for p in audio_dir.iterdir() if p.is_file() and p.suffix.lower() in EXTENSIONS)
    gt_files = sorted(p for p in gt_dir.iterdir() if p.is_file() and p.suffix.lower() == '.txt')
    if not audio_files:
        raise ValueError('No audio files in dataset')
    names = [p.stem for p in audio_files]
    if len(set(names)) != len(names):
        raise ValueError('Duplicate audio stem: two audio files map to same TXT')
    gt_names = {p.stem for p in gt_files}
    if set(names) != gt_names:
        raise ValueError(f'Unmatched files: missing_txt={sorted(set(names)-gt_names)}; extra_txt={sorted(gt_names-set(names))}')
    return [(p, gt_dir / f'{p.stem}.txt') for p in audio_files]


def recognize(mode, adapter, audio, cfg):
    duration = len(audio) / SR
    info = {'duration_sec': duration, 'vad_segments': 0, 'groups': 1, 'speech_kept_ratio': 1.0}
    if mode == 'no_vad':
        return adapter.transcribe(audio, SR), info
    regions = speech_regions(audio, SR, cfg.get('vad', {}))
    if not regions:
        raise ValueError('VAD detected no speech; review audio manually')
    info['vad_segments'] = len(regions)
    info['speech_kept_ratio'] = sum(end-start for start, end in regions) / len(audio)
    if mode == 'vad_concat':
        piece = concat_regions(audio, regions, SR)
        return adapter.transcribe(piece, SR), info
    if mode == 'vad_segments':
        groups = group_regions(regions, SR, float(cfg.get('segment_seconds', 25)))
        info['groups'] = len(groups)
        texts = [adapter.transcribe(audio[a:b], SR) for a, b in groups]
        return ' '.join(t for t in texts if t).strip(), info
    raise ValueError(f'Unknown mode: {mode}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True, choices=sorted(REGISTRY))
    parser.add_argument('--mode', choices=['no_vad', 'vad_concat', 'vad_segments'])
    parser.add_argument('--limit', type=int, default=0, help='0 means all files')
    parser.add_argument('--segment-seconds', type=float)
    parser.add_argument('--audio-dir', type=Path, default=ROOT / 'datasets/benchmark/audio')
    parser.add_argument('--gt-dir', type=Path, default=ROOT / 'datasets/benchmark/ground_truth')
    parser.add_argument('--config', type=Path, default=ROOT / 'configs/models.yaml')
    args = parser.parse_args()
    if args.limit < 0:
        parser.error('--limit must be 0 or positive')
    config_all = yaml.safe_load(args.config.read_text(encoding='utf-8'))
    cfg = dict(config_all[args.model])
    if args.segment_seconds is not None:
        cfg['segment_seconds'] = args.segment_seconds
    mode = args.mode or cfg.get('mode', 'no_vad')
    pairs = get_pairs(args.audio_dir, args.gt_dir)
    if args.limit:
        pairs = pairs[:args.limit]
    print(f'[DATASET] {len(pairs)} matching audio/TXT pairs; model={args.model}, mode={mode}')
    # Load selected model only, after file matching validation.
    adapter = load_model(args.model, cfg)
    out_dir = ROOT / 'results' / args.model / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    out_dir.mkdir(parents=True, exist_ok=False)
    (out_dir / 'run_config.json').write_text(json.dumps({'model': args.model, 'mode': mode, 'model_config': cfg,
            'audio_dir': str(args.audio_dir), 'gt_dir': str(args.gt_dir), 'limit': args.limit}, ensure_ascii=False, indent=2), encoding='utf-8')
    rows = []
    with (out_dir / 'predictions.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        for i, (audio_path, gt_path) in enumerate(pairs, 1):
            row = dict.fromkeys(COLUMNS, '')
            row.update(model=args.model, mode=mode, audio=audio_path.name, ground_truth_file=gt_path.name)
            try:
                truth = gt_path.read_text(encoding='utf-8-sig').strip()
                ref = normalize_text(truth)
                if not ref:
                    raise ValueError('Empty ground truth')
                row['ground_truth'] = truth
                row['normalized_ground_truth'] = ref
                audio = load_audio(audio_path)
                started = time.perf_counter()
                prediction, details = recognize(mode, adapter, audio, cfg)
                elapsed = time.perf_counter() - started
                hyp = normalize_text(prediction)
                measures = score(ref, hyp)
                row.update(prediction=prediction, normalized_prediction=hyp,
                           processing_time_sec=elapsed, status='OK', **details, **measures)
                row['rtf'] = elapsed / details['duration_sec'] if details['duration_sec'] else ''
                print(f'[{i}/{len(pairs)}] {audio_path.name}: WER={measures["wer"]:.2%} CER={measures["cer"]:.2%}')
            except Exception as exc:
                row['status'] = 'ERROR'
                row['error'] = repr(exc)
                print(f'[{i}/{len(pairs)}] ERROR: {audio_path.name}: {exc}')
                traceback.print_exc()
            rows.append(row)
            writer.writerow(row)
            f.flush()
    summary = summarize(rows)
    summary.update(model=args.model, mode=mode, files=len(pairs), output=str(out_dir))
    (out_dir / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print(f'Results: {out_dir}')

if __name__ == '__main__':
    main()
