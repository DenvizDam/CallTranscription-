# CallCSPro — modular ASR benchmark

## Files
- `benchmark.py`: common benchmark CLI, 1 audio paired with 1 TXT via identical stem.
- `models/registry.py`: model selector; adapters in `models/`.
- `preprocessing/`: ffmpeg loader, Silero VAD, grouping.
- `evaluation/`: normalization and WER/CER.
- `configs/models.yaml`: change checkpoints and model-specific mode.
- `results/<model>/<timestamp>/`: separate runs, no overwriting.

## Setup (Ubuntu)
```bash
sudo apt-get install -y ffmpeg
pip install -r requirements.txt
```

Put your 80 original files in `datasets/benchmark/audio/` and the same-name `.txt` files in `datasets/benchmark/ground_truth/`, e.g. `external-001.WAV` pairs with `external-001.txt` (case-sensitive stem). If existing data folders are elsewhere, pass `--audio-dir` and `--gt-dir`.

## PhoWhisper V4 reference
Set your checkpoint in `configs/models.yaml` (default `/home/dtphat/projects/PhoWhisper-base`). The default PhoWhisper mode is `vad_segments`, `segment_seconds=25`, using the same V4 Silero settings and short-segment decoding behavior. Compare result to your prior V4 before claiming exact reproducibility: PyTorch, transformers, CUDA, timestamps, model revision, and VAD backend versions all matter.

```bash
python benchmark.py --model phowhisper --limit 3
python benchmark.py --model phowhisper --limit 0
python benchmark.py --model phowhisper --mode no_vad --limit 3
python benchmark.py --model phowhisper --segment-seconds 20 --limit 0
```

## Other adapters
```bash
python benchmark.py --model whisper_large --limit 3
pip install qwen-asr
python benchmark.py --model qwen3_asr --limit 3
pip install sherpa-onnx
python benchmark.py --model zipformer --limit 3
# For FastConformer, install NVIDIA NeMo following its instructions and supply a compatible .nemo model
python benchmark.py --model fastconformer --limit 3
```

**Important:** other model architectures are not automatically compatible with the V4 speech segmentation. Their recommended `mode` is set separately in the configuration. `zipformer` expects sherpa-onnx offline **transducer** encoder/decoder/joiner ONNX files; different Zipformer export formats require a different adapter. `fastconformer` expects a compatible NeMo checkpoint; `qwen3_asr` uses the official `qwen-asr` Python interface. You must provide the actual checkpoint paths and install optional libraries for those models. No external model weights are shipped. Also validate language support and model licenses.

## Metrics
- Average WER = arithmetic mean across successfully scored files (your primary KPI).
- Corpus WER = aggregate counts across aligned files.
- CER, RTF and per-file CSV are also saved.
- **Review `failed` and verify 80/80 before comparing runs.** Partial results are not comparable to full results.
- RTF measured here is model execution plus VAD, excluding ffmpeg decode/model load; use identical timing scope for cross-model comparison.
- The same 80 files have been used during model selection; reserve a separate independent test set for final comparison.

## Privacy
Customer calls may contain personal data. CSVs contain raw ground truth and predictions; keep results on an approved machine and do not upload them publicly.
