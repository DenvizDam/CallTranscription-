import json
from pathlib import Path
import pandas as pd
from rootcause.cli import transform
from rootcause.reporting import to_dashboard_rows,generate_dashboard,generate_excel_report

def test_full_reporting(tmp_path):
    df=pd.DataFrame([
        {'ID':'1','QID':'q1','Label':'good','ExtraColumn':'keep','Transcript (AI)':'250 triệu', 'Transcript Threshold S2T':0.8,'Transcript Threshold NER':0.7,'Entities Extracted':'FACEAMOUNT: 250000000 (0.0)'},
        {'ID':'2','QID':'q2','Label':'bad','ExtraColumn':'keepbad','Transcript (AI)':'250 triệu', 'Transcript Threshold S2T':0.8,'Transcript Threshold NER':0.7,'Entities Extracted':'FACEAMOUNT: 250 triệu (0.0)'}])
    rc=transform(df)
    assert len(rc)==1 and rc.iloc[0]['RCA_Label']=='S2T' and rc.iloc[0]['ExtraColumn']=='keep'
    rows=to_dashboard_rows(rc)
    assert rows[0]['types']==['FACEAMOUNT']
    out=generate_dashboard(rc,tmp_path/'dash.html')
    html=out.read_text()
    assert '250000000' in html and '__RCA_JSON__' not in html and 'keepbad' not in html
    report=generate_excel_report(rc,tmp_path/'report.xlsx')
    assert report.is_file()
    book=pd.ExcelFile(report)
    assert set(book.sheet_names)=={'Executive Summary','Root Cause','Entity Issues','RCA Data'}
