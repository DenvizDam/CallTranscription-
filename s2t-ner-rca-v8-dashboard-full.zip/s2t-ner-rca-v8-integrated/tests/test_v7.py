import json
import pandas as pd
import pytest
from rootcause.engine import classify
from rootcause.cli import transform, run


def check(s,n,t,e):
    return classify(s,n,t,e).label


def test_threshold_rules():
    assert check(1,1,'','')=='No Error'
    assert check(1,.5,'','')=='NER'
    assert check(.5,1,'','')=='S2T'


def test_all_entities_match_and_ignore_score():
    e='FACEAMOUNT: 250000000 (0.0)\nPREMIUMTERM: 53 (1.0)\nSUNDRYAMOUNT: 22100000 (0.66667)\nPREMIUMMODE: năm (1.0)'
    assert check(.5,.5,'Bảo hiểm 250 triệu, thời hạn 53 năm, phí 22 triệu 100 nghìn, đóng phí năm',e)=='S2T'


def test_not_match():
    assert check(.5,.5,'250 triệu','FACEAMOUNT: 260000000 (0.0)')=='Both Phase'


def test_amount_wrong_format_even_if_same_meaning():
    assert check(.5,.5,'250 triệu','FACEAMOUNT: 250 triệu (1.0)')=='Both Phase'
    assert check(.5,.5,'250 triệu','FACEAMOUNT: hai trăm năm mươi triệu')=='Both Phase'


def test_no_wrong_entity_context_check():
    assert check(.5,.5,'Phí 20 triệu, mệnh giá 250 triệu','FACEAMOUNT: 20000000')=='S2T'


def test_missing_and_invalid():
    assert check(.5,.5,'250 triệu','')=='Need Review'
    assert check(.5,.5,'','FACEAMOUNT: 250000000')=='Need Review'
    assert check(1.1,.5,'x','X: x')=='Need Review'
    assert check(-.1,.5,'x','X: x')=='Need Review'


def test_only_good_preserve_original_columns():
    df=pd.DataFrame({'Label':['good','bad',' GOOD ',''], 'Extra':['a','b','c','d'],
       'Transcript (AI)':['250 triệu']*4, 'Transcript Threshold S2T':[.7]*4,
       'Transcript Threshold NER':[.6]*4, 'Entities Extracted':['FACEAMOUNT: 250000000']*4})
    out=transform(df)
    assert len(out)==2
    assert out['Extra'].tolist()==['a','c']
    assert out['RCA_Label'].tolist()==['S2T','S2T']
    assert df.shape==(4,6)


def test_cli_roundtrip(tmp_path):
    x=tmp_path/'test.csv'; y=tmp_path/'result.xlsx'
    pd.DataFrame({'Label':['good','bad'], 'Other':['keep','skip'],
      'Transcript (AI)':['22 triệu 100 nghìn','hi'],
      'Transcript Threshold S2T':[.8,1], 'Transcript Threshold NER':[.8,1],
      'Entities Extracted':['SUNDRYAMOUNT: 22100000 (0.0)','X: a']}).to_csv(x,index=False)
    run(x,y)
    out=pd.read_excel(y)
    assert len(out)==1 and out.loc[0,'RCA_Label']=='S2T' and out.loc[0,'Other']=='keep'


def test_invalid_amount_preserves_raw():
    r=classify(.6,.6,'250 triệu','FACEAMOUNT: 250 triệu (0.0)')
    assert r.label=='Both Phase'
    assert json.loads(r.entity_checks)[0]['value']=='250 triệu'


def test_reprocessing_rca_columns():
    df=pd.DataFrame({'Label':['good'],'Transcript (AI)':['250 triệu'],
        'Transcript Threshold S2T':[.7], 'Transcript Threshold NER':[.7],
        'Entities Extracted':['FACEAMOUNT: 250000000'],'RCA_Label':['old']})
    assert transform(df)['RCA_Label'].iloc[0]=='S2T'
