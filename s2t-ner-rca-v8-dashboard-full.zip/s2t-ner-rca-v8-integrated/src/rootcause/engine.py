"""Versioned deterministic 7-rule root-cause classifier (business rules, not scientific proof)."""
from __future__ import annotations
from dataclasses import dataclass
import json
from .matching import score, missing, parse_entities, detail_matches


@dataclass(frozen=True)
class Result:
    label: str
    reason: str
    ner_check: str
    review: str
    entity_checks: str


def _result(label, reason, status='Not Checked', details=None):
    return Result(label, reason, status, 'Yes' if label == 'Need Review' else 'No',
                  json.dumps(details or [], ensure_ascii=False))


def classify(s2t, ner, transcript, extracted, to_extract=None) -> Result:
    """Evaluate only entity VALUE presence in AI transcript (no type/context/GT check).

    to_extract is retained as a backwards-compatible argument but is deliberately ignored.
    """
    s, n = score(s2t), score(ner)
    if s is None or n is None:
        return _result('Need Review', 'Threshold S2T hoặc NER trống / ngoài khoảng [0, 1].', 'Unknown')
    if s == 1 and n == 1:
        return _result('No Error', 'S2T và NER cùng đạt threshold 1.')
    if s == 1 and n < 1:
        return _result('NER', 'S2T đạt threshold 1, NER dưới 1.')
    if s < 1 and n == 1:
        return _result('S2T', 'S2T dưới threshold 1, NER đạt 1.')

    # The remaining four rules require evidence from NER outputs versus AI transcript.
    if missing(transcript):
        return _result('Need Review', 'Thiếu Transcript (AI); không thể đối chiếu.', 'Unknown')
    entries, valid = parse_entities(extracted)
    if not valid or not entries:
        return _result('Need Review', 'Entities Extracted rỗng hoặc không parse được.', 'Unknown')
    checks = detail_matches(entries, transcript)
    invalid = [c['type'] for c in checks if not c['format_valid']]
    if invalid:
        return _result('Both Phase', 'S2T dưới 1; entity AMOUNT sai định dạng: '+', '.join(invalid)+'.', 'Invalid Format', checks)
    unmatched = [c['type'] + ': ' + str(c['value']) for c in checks if not c['value_found']]
    if unmatched:
        return _result('Both Phase', 'S2T dưới 1; entity không xuất hiện trong Transcript (AI): '+ '; '.join(unmatched)+'.', 'Not Match', checks)
    return _result('S2T', 'S2T dưới 1; toàn bộ entity xuất hiện trong Transcript (AI) và đúng định dạng AMOUNT.', 'Match', checks)
