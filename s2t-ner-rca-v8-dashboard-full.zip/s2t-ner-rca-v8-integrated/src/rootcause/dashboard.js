const data=__RCA_JSON__;
const cats=['S2T','NER','Both Phase','No Error','Need Review'];
const colors={'S2T':'#245ac2','NER':'#7555b7','Both Phase':'#cf5567','No Error':'#128b76','Need Review':'#c88e19'};
const klass={'S2T':'s2t','NER':'ner','Both Phase':'both','No Error':'clean','Need Review':'review'};
const $=id=>document.getElementById(id);
const fmt=n=>Number(n||0).toLocaleString('vi-VN');
const pct=(n,d)=>d?Math.round(1000*n/d)/10:0;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let subset=[];
const typeFilter=$('typeFilter');
const allTypes=[...new Set(data.flatMap(r=>r.types||[]))].sort();
typeFilter.innerHTML='<option value="all">Tất cả loại entity</option>'+allTypes.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join('');
function render(){
const label=$('rootFilter').value,check=$('entityFilter').value,type=typeFilter.value,search=$('search').value.toLowerCase().trim();
subset=data.filter(x=>(label==='all'||x.label===label)&&(check==='all'||x.check===check)&&(type==='all'||(x.types||[]).includes(type))&&(!search||String(x.id).toLowerCase().includes(search)||String(x.qid).toLowerCase().includes(search)));
const count=Object.fromEntries(cats.map(c=>[c,subset.filter(r=>r.label===c).length]));
const total=subset.length;
const cards=[['Tổng bản ghi',total,''],['S2T',count.S2T,'s2t'],['NER',count.NER,'ner'],['Both Phase',count['Both Phase'],'both'],['No Error',count['No Error'],'clean'],['Cần xem lại',count['Need Review'],'review']];
$('kpis').innerHTML=cards.map(([t,v,cl])=>`<div class="card kpi ${cl}"><div class="name">${t}</div><div class="number">${fmt(v)}</div><div class="pct">${t==='Tổng bản ghi'?'Label = good':pct(v,total)+'% bản ghi'}</div></div>`).join('');
const max=Math.max(1,...Object.values(count));
$('bars').innerHTML=cats.map(c=>`<div class="barrow"><span>${esc(c)}</span><div class="track"><div class="bar" style="width:${count[c]/max*100}%;background:${colors[c]}"></div></div><b>${fmt(count[c])} <span class="muted">(${pct(count[c],total)}%)</span></b></div>`).join('');
let start=0;let parts=cats.map(c=>{const end=start+(total?count[c]/total*100:0);const p=`${colors[c]} ${start}% ${end}%`;start=end;return p;});
$('donut').style.background=total?`conic-gradient(${parts.join(',')})`:'#e7ecf2';
$('totalDonut').textContent=fmt(total);
$('legend').innerHTML=cats.map(c=>`<div><span class="dot" style="background:${colors[c]}"></span>${esc(c)} <strong>${pct(count[c],total)}%</strong></div>`).join('');
for(const [key,id,bar] of [['s','s2tavg','s2tprogress'],['n','neravg','nerprogress']]){const nums=subset.map(x=>Number(x[key])).filter(Number.isFinite);const avg=nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:null;$(id).textContent=avg===null?'—':avg.toFixed(3);$(bar).style.width=(avg===null?0:Math.min(100,avg*100))+'%';}
const checked=subset.filter(x=>['Match','Not Match','Invalid Format'].includes(x.check));
const matches=checked.filter(x=>x.check==='Match').length;
$('matchPct').textContent=checked.length?pct(matches,checked.length)+'%':'—';$('matchProgress').style.width=pct(matches,checked.length)+'%';$('matchCaption').textContent=`${matches}/${checked.length} bản ghi đã kiểm tra có trạng thái Match`;
const counts={};subset.forEach(x=>{for(const d of (x.checks||[])){if(d.status==='Not Match'||d.status==='Invalid Format'){counts[d.type]=(counts[d.type]||0)+1;}}});
const ents=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,6);const mx=Math.max(1,...ents.map(x=>x[1]));
$('entities').innerHTML=ents.length?ents.map(([t,v])=>`<div class="entityrow"><span>${esc(t)}</span><div class="smalltrack"><div style="width:${v/mx*100}%"></div></div><b>${v}</b></div>`).join(''):'<div class="muted">Không có entity không khớp trong bộ lọc.</div>';
$('tableSummary').textContent=`Hiển thị ${Math.min(100,total)} / ${fmt(total)} bản ghi. Xuất CSV để lấy toàn bộ bản ghi đang lọc.`;
$('tableBody').innerHTML=subset.slice(0,100).map(x=>`<tr><td>${esc(x.id)}</td><td>${esc(x.qid)}</td><td>${Number.isFinite(Number(x.s))?Number(x.s).toFixed(3):'—'}</td><td>${Number.isFinite(Number(x.n))?Number(x.n).toFixed(3):'—'}</td><td title="${esc(x.entity)}">${esc(String(x.entity).slice(0,65))}</td><td><span class="pill ${klass[x.label]||''}">${esc(x.label)}</span></td><td>${esc(x.check)}</td><td>${esc(x.review)}</td><td title="${esc(x.reason)}">${esc(String(x.reason).slice(0,140))}</td></tr>`).join('')||'<tr><td colspan="9" class="muted" style="text-align:center;padding:28px">Không có bản ghi phù hợp.</td></tr>';
}
for(const id of ['rootFilter','entityFilter','typeFilter'])$(id).addEventListener('change',render);
$('search').addEventListener('input',render);
$('reset').addEventListener('click',()=>{$('rootFilter').value='all';$('entityFilter').value='all';typeFilter.value='all';$('search').value='';render();});
function csvCell(s){const value=String(s??'');const safe=/^[\s]*[=+@\-]/.test(value)?"'"+value:value;return '"'+safe.replaceAll('"','""')+'"';}
function exportCsv(){const cols=['ID','QID','Transcript Threshold S2T','Transcript Threshold NER','Entities Extracted','RCA_Label','RCA_NER_Check','RCA_Review','RCA_Reason'];const rows=subset.map(x=>[x.id,x.qid,x.s,x.n,x.entity,x.label,x.check,x.review,x.reason]);const csv='\uFEFF'+[cols,...rows].map(r=>r.map(csvCell).join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='rca_filtered.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
$('export').addEventListener('click',exportCsv);$('detailsExport').addEventListener('click',exportCsv);render();