"""Build offline interactive dashboard and Excel report from V7 RCA output."""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import json
import math
import pandas as pd

LABELS = ['S2T','NER','Both Phase','No Error','Need Review']

def _string(x):
    return '' if pd.isna(x) else str(x)

def _number(x):
    try:
        n=float(x)
        return n if math.isfinite(n) else None
    except (TypeError, ValueError):
        return None

def _details(value):
    if not isinstance(value, str) or not value.strip():
        return []
    try:
        obj=json.loads(value)
        if not isinstance(obj,list):
            return []
        rows=[]
        for item in obj:
            if not isinstance(item,dict):
                continue
            name=_string(item.get('type',''))
            if not name:
                continue
            status=('Invalid Format' if item.get('format_valid') is False
                    else 'Match' if item.get('value_found') is True
                    else 'Not Match' if item.get('value_found') is False
                    else 'Unknown')
            rows.append({'type':name,'value':_string(item.get('value','')),'status':status})
        return rows
    except (json.JSONDecodeError, TypeError):
        return []

def to_dashboard_rows(df):
    needed=['RCA_Label','RCA_NER_Check','RCA_Reason','RCA_Entity_Details']
    absent=[x for x in needed if x not in df.columns]
    if absent: raise ValueError('Thiếu cột RCA: '+', '.join(absent))
    if 'Label' in df.columns:
        df=df.loc[df['Label'].astype('string').str.strip().str.casefold().eq('good').fillna(False)]
    records=[]
    for index,row in df.iterrows():
        checks=_details(row.get('RCA_Entity_Details'))
        records.append({'id':_string(row.get('ID',index+1)), 'qid':_string(row.get('QID','')),
            's':_number(row.get('Transcript Threshold S2T')),'n':_number(row.get('Transcript Threshold NER')),
            'label':_string(row.get('RCA_Label')),'check':_string(row.get('RCA_NER_Check')),
            'review':_string(row.get('RCA_Review')),'reason':_string(row.get('RCA_Reason')),
            'entity':_string(row.get('Entities Extracted')),
            'types':list(dict.fromkeys(d['type'] for d in checks)), 'checks':checks})
    return records

def generate_dashboard(df, path):
    path=Path(path)
    rows=to_dashboard_rows(df)
    src=Path(__file__).with_name('dashboard_template.html').read_text(encoding='utf-8')
    script=Path(__file__).with_name('dashboard.js').read_text(encoding='utf-8')
    raw=json.dumps(rows,ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    script=script.replace('__RCA_JSON__',raw)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(src.replace('__DASHBOARD_SCRIPT__',script),encoding='utf-8')
    return path

def generate_excel_report(df, path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    rows=to_dashboard_rows(df)
    total=len(rows)
    distribution=pd.DataFrame([{'Root Cause':lab,'Số bản ghi':sum(x['label']==lab for x in rows),
        'Tỷ lệ (%)':round(100*sum(x['label']==lab for x in rows)/total,2) if total else 0} for lab in LABELS])
    checked=[x for x in rows if x['check'] in ('Match','Not Match','Invalid Format')]
    matches=sum(x['check']=='Match' for x in checked)
    s=[x['s'] for x in rows if x['s'] is not None];n=[x['n'] for x in rows if x['n'] is not None]
    kpis=pd.DataFrame([
        ('Tổng bản ghi Label=good',total),('Số bản ghi được kiểm tra entities',len(checked)),
        ('Tỷ lệ Match trên bản ghi đã kiểm tra (%)',round(100*matches/len(checked),2) if checked else None),
        ('Threshold S2T trung bình',round(sum(s)/len(s),4) if s else None),
        ('Threshold NER trung bình',round(sum(n)/len(n),4) if n else None),
        ('Bản ghi Need Review',sum(x['label']=='Need Review' for x in rows))],columns=['Chỉ số','Giá trị'])
    tally=Counter()
    for x in rows:
        for d in x['checks']:
            if d['status'] in ('Not Match','Invalid Format'):
                tally[(d['type'],d['status'])]+=1
    entities=pd.DataFrame([{'Entity':e,'Trạng thái':status,'Số lần':count} for (e,status),count in tally.most_common()],columns=['Entity','Trạng thái','Số lần'])
    with pd.ExcelWriter(path,engine='openpyxl') as writer:
        kpis.to_excel(writer,sheet_name='Executive Summary',index=False)
        distribution.to_excel(writer,sheet_name='Root Cause',index=False)
        entities.to_excel(writer,sheet_name='Entity Issues',index=False)
        # Preserve original RCA output in another sheet; never modify its values.
        df.to_excel(writer,sheet_name='RCA Data',index=False)
        from openpyxl.styles import Font,PatternFill,Alignment
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2'
            ws.auto_filter.ref=ws.dimensions
            for c in ws[1]:
                c.fill=PatternFill('solid',fgColor='152945');c.font=Font(color='FFFFFF',bold=True)
                c.alignment=Alignment(vertical='center')
            ws.row_dimensions[1].height=28
            for col in ws.columns:
                letter=col[0].column_letter
                width=min(58,max(13,max(len(str(cell.value or '')) for cell in list(col)[:150])+3))
                ws.column_dimensions[letter].width=width
    return path
