"""Command-line runner: export ONLY Label=good while preserving all other original columns."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from .engine import classify

REQUIRED = ('Label', 'Transcript (AI)', 'Transcript Threshold S2T', 'Transcript Threshold NER', 'Entities Extracted')
ADDED = ('RCA_Label', 'RCA_Reason', 'RCA_NER_Check', 'RCA_Review', 'RCA_Entity_Details')


def load_dataset(path, sheet=0):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Không tìm thấy dataset: {path}')
    if path.suffix.lower() in ('.xlsx', '.xlsm'):
        return pd.read_excel(path, sheet_name=sheet, dtype=object)
    if path.suffix.lower() == '.csv':
        return pd.read_csv(path, dtype=object, encoding='utf-8-sig', keep_default_na=False)
    raise ValueError('Input phải là .xlsx/.xlsm/.csv')


def transform(df):
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError('Thiếu cột: ' + ', '.join(missing))
    # Reprocessing an earlier export is allowed: replace RCA columns, preserve everything else.
    base = df.drop(columns=[c for c in ADDED if c in df.columns]).copy()
    good = base['Label'].astype('string').str.strip().str.casefold().eq('good').fillna(False)
    result = base.loc[good].copy()
    records=[]
    for _, row in result.iterrows():
        r=classify(row['Transcript Threshold S2T'], row['Transcript Threshold NER'], row['Transcript (AI)'], row['Entities Extracted'])
        records.append((r.label, r.reason, r.ner_check, r.review, r.entity_checks))
    for i, col in enumerate(ADDED):
        result[col] = [r[i] for r in records]
    return result


def run(input_path, output_path, sheet=0):
    input_path, output_path = Path(input_path), Path(output_path)
    if input_path.resolve() == output_path.resolve():
        raise ValueError('Không được ghi đè input; chọn đường dẫn output khác.')
    data = load_dataset(input_path, sheet)
    output = transform(data)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.suffix.lower() == '.xlsx':
        output.to_excel(output_path, index=False)
    elif output_path.suffix.lower() == '.csv':
        output.to_csv(output_path, index=False, encoding='utf-8-sig')
    else:
        raise ValueError('Output phải là .xlsx hoặc .csv')
    print(f'Input: {len(data)} dòng | Label=good: {len(output)} dòng | Loại: {len(data)-len(output)} dòng')
    print(f'Đã lưu: {output_path}')
    print(output['RCA_Label'].value_counts(dropna=False).to_string() if len(output) else 'Không có Label=good')
    return output


def main():
    p=argparse.ArgumentParser(description='S2T / NER RCA - Python only V7')
    p.add_argument('--input', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--sheet', default='0', help='Tên sheet hoặc vị trí sheet (mặc định 0)')
    a=p.parse_args()
    sheet=int(a.sheet) if a.sheet.isdecimal() else a.sheet
    run(a.input, a.output, sheet)

if __name__ == '__main__':
    main()
