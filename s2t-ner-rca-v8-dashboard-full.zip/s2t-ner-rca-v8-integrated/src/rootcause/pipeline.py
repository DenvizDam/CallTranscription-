"""Integrated V7 classifier + offline dashboard + Excel management report."""
import argparse
from pathlib import Path
from .cli import run
from .reporting import generate_dashboard, generate_excel_report

def main():
    parser=argparse.ArgumentParser(description='RCA Python-only + Dashboard + Excel Report')
    parser.add_argument('--input',required=True)
    parser.add_argument('--output',default='output/rca_result.xlsx')
    parser.add_argument('--dashboard',default='output/dashboard.html')
    parser.add_argument('--report',default='output/rca_report.xlsx')
    parser.add_argument('--sheet',default='0')
    args=parser.parse_args()
    inputs=[Path(args.input).resolve()]
    outputs=[Path(x).resolve() for x in (args.output,args.dashboard,args.report)]
    if any(x in inputs for x in outputs) or len(set(outputs))!=3:
        parser.error('Các đường dẫn input, RCA output, dashboard và report phải khác nhau.')
    sheet=int(args.sheet) if args.sheet.isdecimal() else args.sheet
    df=run(args.input,args.output,sheet)
    print('Dashboard:',generate_dashboard(df,args.dashboard))
    print('Excel report:',generate_excel_report(df,args.report))

if __name__=='__main__':main()
