# S2T / NER Root Cause Classifier V7 — Python Only

Công cụ đối chiếu `Entities Extracted` **chỉ với** `Transcript (AI)` để phân loại lỗi theo 7 quy tắc đã thống nhất. Không gọi LLM, không cần `.env`, không gọi API và không dùng `TextScript` để kiểm tra NER.

## Cài đặt (Ubuntu + Conda)

```bash
conda create -n s2t_rca python=3.11 -y
conda activate s2t_rca
python -m pip install -e .
python -m pip install pytest
python -m pytest -q
```

Hoặc dùng `conda env create -f environment.yml` nếu **chưa** có môi trường `s2t_rca`.

## Chạy

```bash
python -m rootcause.cli --input input/dataset.xlsx --output output/rca.xlsx
```

CSV cũng được hỗ trợ:

```bash
python -m rootcause.cli --input examples/sample.csv --output output/sample_result.csv
```

Đối với file Excel nhiều sheet, thêm `--sheet TenSheet` hoặc `--sheet 0`.

## Quy tắc

| S2T | NER | Entities vs Transcript (AI) | Kết luận |
| --- | --- | --- | --- |
| =1 | =1 | Bỏ qua | No Error |
| =1 | <1 | Bỏ qua | NER |
| <1 | =1 | Bỏ qua | S2T |
| <1 | <1 | Tất cả giá trị xuất hiện, AMOUNT đúng định dạng | S2T |
| <1 | <1 | Ít nhất một giá trị không xuất hiện | Both Phase |
| <1 | <1 | Ít nhất một AMOUNT sai định dạng | Both Phase |
| <1 | <1 | Thiếu/unparseable data | Need Review |

Điểm số phải là số hữu hạn trong `[0,1]`, nếu không thì `Need Review`.

## Nguyên tắc về Entity

- Tách từng dòng `NAME: value (score)` trong `Entities Extracted`. Chỉ bỏ hậu tố score `(0.0)` v.v.; **giữ nguyên chuỗi value**.
- Với entity có tên kết thúc bằng `AMOUNT` hoặc `MONEY`, value phải gồm **các chữ số nguyên không âm**, không được có đơn vị hoặc chữ. Ví dụ `FACEAMOUNT: 250 triệu` là sai định dạng dù giá trị tương đương.
- Ở phía **Transcript (AI)**, đối chiếu giá trị số với những cách viết như `250 triệu`, `2,5 tỷ`, `22 triệu 100 nghìn`, `250000000`, `250.000.000`. Tính năng dựa trên những mẫu đã được hỗ trợ, không bảo đảm bao phủ mọi câu đọc số bằng chữ.
- Giá trị entity khác so với Transcript (AI) → Not Match. **Không kiểm tra loại hay ngữ cảnh** và không so với Ground Truth. Việc một giá trị có xuất hiện không chứng minh NER đúng về nghiệp vụ; đây là *quy ước phân loại* của dự án.
- `Entities To Extract` và `TextScript` **không dùng** trong rule engine này; những cột đó vẫn được giữ trong output.

## Dữ liệu đầu vào / đầu ra

Các cột bắt buộc: `Label`, `Transcript (AI)`, `Transcript Threshold S2T`, `Transcript Threshold NER`, `Entities Extracted`.

- Chỉ giữ các hàng có `Label = good` (không phân biệt viết hoa, bỏ khoảng trắng đầu/cuối).
- **Mọi cột gốc** của các hàng `good` được giữ; dữ liệu đầu vào không bị chỉnh sửa.
- Xuất thêm đúng 5 cột: `RCA_Label`, `RCA_Reason`, `RCA_NER_Check`, `RCA_Review`, `RCA_Entity_Details`.
- `RCA_Entity_Details` là JSON cho từng entity, gồm `type`, `value`, `format_valid`, `value_found`, `match_mode`.
- Nếu đã có các cột `RCA_*` kể trên trong input, chương trình tạo lại chúng ở cuối output.
- Chương trình **không cho ghi đè lên file input**.

## Giới hạn cần biết

- Không xác minh loại entity, thiếu entity, hoặc mối liên hệ với vị trí cụ thể trong transcript, theo yêu cầu nghiệp vụ.
- Entity có giá trị nằm trong transcript có thể vẫn bị gán sai loại, nhưng rule hiện tại sẽ coi là match.
- Các dạng đọc tiền chỉ bằng chữ (như “hai trăm năm mươi triệu”) và một số chuỗi tiền phức tạp có thể chưa match; kiểm thử các mẫu thực tế rồi bổ sung parser trước khi dùng chính thức.
- `Both Phase` và `S2T` là **nhãn theo quy ước threshold và presence**, không phải kết luận nhân quả tuyệt đối.
- Pandas ghi lại một file Excel **mới**; nó giữ giá trị/cột nhưng không cam kết giữ các định dạng, comment, macro hay công thức gốc.

## Cấu trúc dự án

```text
src/rootcause/engine.py       # Quy tắc 7 nhánh
src/rootcause/matching.py     # Parser, so khớp, AMOUNT
src/rootcause/cli.py          # CLI + lọc good + xuất
examples/sample.csv          # Data mẫu
input/ output/                # Folder đặt data (Git bỏ qua)
tests/test_v7.py              # Tests
.github/workflows/tests.yml  # CI tests
```
