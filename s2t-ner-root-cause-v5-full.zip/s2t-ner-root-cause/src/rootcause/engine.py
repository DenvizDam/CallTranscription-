"""Deterministic triage. Thresholds are flags, NOT root-cause proof."""
import ast
import decimal
import json
import math
import re
import unicodedata
from dataclasses import dataclass
from typing import Any


@dataclass
class Result:
    label: str
    reason: str
    needs_llm: bool = False
    candidate: str = ""


def missing(value: Any) -> bool:
    if value is None: return True
    if isinstance(value, float) and math.isnan(value): return True
    return isinstance(value, str) and not value.strip()


def score(value: Any) -> float | None:
    if missing(value): return None
    try:
        number = float(str(value).strip().replace(",", "."))
        return number if math.isfinite(number) and 0 <= number <= 1 else None
    except (TypeError, ValueError): return None


def normalize(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value)).casefold().strip()


def parse_entities(raw: Any) -> tuple[list[dict], bool]:
    """Supports JSON dict/list, list of {type,value}, or Python literal.

    A plain unstructured string must be reviewed rather than falsely treated as valid.
    """
    if missing(raw): return [], False
    # Excel multiline format: ENTITY_NAME: value (numeric-score). Score is deliberately ignored.
    if isinstance(raw, str) and not raw.lstrip().startswith(('{', '[')):
        rows = [line.strip() for line in raw.splitlines() if line.strip()]
        if not rows:
            return [], False
        parsed = []
        for line in rows:
            match = re.fullmatch(r"([A-Za-z][A-Za-z0-9_ .-]*)\s*:\s*(.+?)\s*", line)
            if not match:
                return [], False
            name, value = match.group(1).strip(), match.group(2).strip()
            # Remove only a numeric parenthesized suffix (not parentheses inside an entity value).
            value = re.sub(r"\s*\(\s*[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)\s*\)\s*$", "", value).strip()
            if not value:
                return [], False
            parsed.append({"type": name, "value": value})
        return normalize_entries(parsed)
    value = raw
    if isinstance(raw, str):
        try: value = json.loads(raw)
        except (ValueError, TypeError):
            try: value = ast.literal_eval(raw)
            except (SyntaxError, ValueError): return [], False
    entries = []
    if isinstance(value, dict):
        if "type" in value and "value" in value:
            entries = [{"type": str(value["type"]), "value": str(value["value"])}]
        else:
            for k, v in value.items():
                vals = v if isinstance(v, list) else [v]
                for x in vals:
                    if isinstance(x, (str, int, float)) and not missing(x):
                        entries.append({"type": str(k), "value": str(x)})
                    elif isinstance(x, dict) and "value" in x:
                        entries.append({"type": str(k), "value": str(x["value"])})
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, dict) and "type" in item and "value" in item:
                entries.append({"type": str(item["type"]), "value": str(item["value"])})
            else: return [], False
    else: return [], False
    return normalize_entries(entries)


AMOUNT_SUFFIX = re.compile(r"(?:AMOUNT|_AMOUNT|MONEY|_MONEY)$", re.I)


def is_amount_entity(entity_type: str) -> bool:
    return bool(AMOUNT_SUFFIX.search(str(entity_type).strip()))


def parse_amount_value(raw: Any) -> int | None:
    """Output numeric integer (VND), never a spelled-out value for *_AMOUNT entities."""
    if isinstance(raw, bool):
        return None
    text = unicodedata.normalize("NFKC", str(raw)).strip()
    text = re.sub(r"\s*(?:đ|vnd|đồng)\s*$", "", text, flags=re.I).strip()
    if re.fullmatch(r"[+-]?\d+", text):
        return int(text) if int(text) >= 0 else None
    if re.fullmatch(r"\d{1,3}(?:[., ]\d{3})+", text):
        return int(re.sub(r"[., ]", "", text))
    return None


def amount_mentions(transcript: Any) -> list[int]:
    """Extract monetary numeric forms, including compound '22 triệu 100 nghìn'.

    Excludes standalone numbers with no currency/unit, except explicit long integers.
    """
    text = normalize(transcript)
    text = re.sub(r"(?<=\d)[.] (?=\d)", ".", text)
    # Group separators only for full three-digit groups, comma decimals otherwise.
    text = re.sub(r"(?<!\d)(\d{1,3}(?:[.]\d{3})+)(?!\d)", lambda m:m.group(1).replace(".",""), text)
    rx = re.compile(r"(?<![\w])(?P<num>\d+(?:[.,]\d+)?)\s*(?P<unit>tỷ|tỉ|triệu|nghìn|ngàn)(?![\w])")
    chunks = []
    for match in rx.finditer(text):
        unit = match.group('unit')
        mult = {'tỷ': 10**9, 'tỉ': 10**9, 'triệu': 10**6, 'nghìn': 10**3, 'ngàn': 10**3}[unit]
        try:
            value = decimal.Decimal(match.group('num').replace(',', '.')) * mult
            if value == int(value):
                chunks.append((match.start(), match.end(), int(value), mult))
        except (decimal.InvalidOperation, ValueError):
            continue
    amounts = [c[2] for c in chunks]
    # Combine consecutive decreasing units, allowing 'đồng', punctuation only at end.
    for i in range(len(chunks)):
        current = chunks[i][2]
        last_end = chunks[i][1]
        last_mult = chunks[i][3]
        for next_chunk in chunks[i+1:]:
            middle = text[last_end:next_chunk[0]]
            if len(middle) > 6 or middle.strip() not in ('', 'và') or next_chunk[3] >= last_mult:
                break
            current += next_chunk[2]
            amounts.append(current)
            last_mult = next_chunk[3]
            last_end = next_chunk[1]
    # Literal integers e.g. 250000000 or 250.000.000 are valid too.
    for match in re.finditer(r"(?<![\w])\d{5,}(?![\w])", text):
        amounts.append(int(match.group()))
    return amounts


def numeric_equivalent_in_transcript(value: str, transcript: str) -> bool:
    expected = parse_amount_value(value)
    return expected is not None and expected in amount_mentions(transcript)


def normalize_entries(entries: list[dict]) -> tuple[list[dict], bool]:
    """Preserve EXACT extracted values. NEVER fix or coerce the NER output."""
    return [dict(e) for e in entries], True


def entity_format_valid(entry: dict) -> bool:
    if is_amount_entity(entry["type"]):
        # Strict output contract: nonnegative ungrouped digits only, no words/units.
        return bool(re.fullmatch(r"\d+", str(entry["value"])))
    return True


def presence(entries: list[dict], transcript: Any) -> bool:
    t = normalize(transcript)
    if not t or not entries: return False
    # Strict literal substring: this is ONLY a preliminary test, not proof of correct NER.
    return all(
        (bool(re.search(r"(?<![\w])" + re.escape(normalize(e["value"])) + r"(?![\w])", t))
         or numeric_equivalent_in_transcript(e["value"], t))
        for e in entries
    )


# Đây chỉ là bằng chứng khớp GIÁ TRỊ, không mặc định chứng minh đúng nhãn hoặc ngữ cảnh.
ROLE_HINTS = {
    "FACEAMOUNT": ("mệnh giá", "số tiền bảo hiểm", "quyền lợi bảo hiểm"),
    "SUNDRYAMOUNT": ("phí phụ", "phí bổ sung", "số tiền bổ sung"),
    "PREMIUMTERM": ("thời hạn đóng phí", "thời hạn phí", "đóng phí trong"),
    "PREMIUMMODE": ("định kỳ đóng phí", "phương thức đóng phí", "đóng phí theo"),
    "AGENTCODE": ("mã nhân viên", "mã tư vấn viên", "mã đại lý"),
}


def detail_matches(entries: list[dict], transcript: Any) -> list[dict]:
    """So khớp từng value với Transcript (AI), KHÔNG dùng TextScript để phán lỗi NER."""
    t = normalize(transcript)
    items = []
    for ent in entries:
        value = normalize(ent['value'])
        literal = bool(value and re.search(r"(?<![\w])" + re.escape(value) + r"(?![\w])", t))
        numeric = numeric_equivalent_in_transcript(value, t)
        format_ok = entity_format_valid(ent)
        matched = (literal or numeric) and format_ok
        hints = ROLE_HINTS.get(str(ent['type']).upper(), ())
        # Keyword toàn transcript không đủ bảo đảm value nằm đúng ngữ cảnh.
        role_hint_found = bool(hints and any(h in t for h in hints))
        items.append({"type": ent['type'], "value": ent['value'],
                      "value_found": matched, "format_valid": format_ok,
                      "match_mode": "literal" if literal else "numeric" if numeric else "none",
                      "role_hint_in_transcript": role_hint_found})
    return items


def classify(s2t_raw: Any, ner_raw: Any, transcript: Any, entities_raw: Any) -> Result:
    s, n = score(s2t_raw), score(ner_raw)
    if s is None or n is None: return Result("Need Review", "Thiếu hoặc sai định dạng threshold")
    if s == 1 and n == 1: return Result("No Error", "Hai threshold đều đạt mốc 1")
    if s == 1 and n < 1: return Result("NER", "S2T đạt mốc; NER dưới mốc")
    if s < 1 and n == 1: return Result("S2T", "S2T dưới mốc; NER đạt mốc")
    if missing(transcript): return Result("Need Review", "Thiếu Transcript (AI); không thể kiểm tra NER", True)
    entries, valid = parse_entities(entities_raw)
    if not valid or not entries:
        return Result("Need Review", "Entities Extracted trống hoặc không parse được; chưa đủ bằng chứng", True)
    checks = detail_matches(entries, transcript)
    invalid_format = [x['type'] for x in checks if not x['format_valid']]
    if invalid_format:
        return Result("Both Phase", "S2T dưới mốc và NER sai định dạng AMOUNT: " + ", ".join(invalid_format), False, "Both Phase")
    found = sum(int(x['value_found']) for x in checks)
    if found == len(checks):
        return Result("Need Review", f"{found}/{len(checks)} entity có giá trị khớp Transcript (AI), nhưng cần xác minh loại/ngữ cảnh và entity bị thiếu", True, "S2T")
    return Result("Need Review", f"Chỉ {found}/{len(checks)} entity khớp Transcript (AI); có thể khác cách đọc hoặc lỗi NER, cần xác minh", True, "Both Phase")
