import argparse
import json
import os
from pathlib import Path
import pandas as pd
from dotenv import load_dotenv
from .engine import classify, parse_entities, detail_matches

REQUIRED = ["Label", "TextScript", "Transcript (AI)", "Transcript Threshold S2T", "Transcript Threshold NER", "Entities Extracted"]
RESULT_COLS = ["RCA_Label", "RCA_Reason", "RCA_Method", "RCA_Confidence", "RCA_Evidence", "RCA_Candidate", "RCA_Rule_Label", "RCA_LLM_Label", "RCA_LLM_Status", "RCA_Entity_Checks"]


def process_frame(df: pd.DataFrame, use_llm: bool = False, all_rows: bool = True) -> pd.DataFrame:
    missing_cols = [c for c in REQUIRED if c not in df.columns]
    if missing_cols: raise ValueError("Thiếu cột bắt buộc: " + ", ".join(missing_cols))
    out = df.copy(deep=True)
    conflicts = [c for c in RESULT_COLS if c in out.columns]
    if conflicts: raise ValueError("Dữ liệu có sẵn cột RCA_, tránh ghi đè: " + ", ".join(conflicts))
    for c in RESULT_COLS: out[c] = ""
    mask = out["Label"].astype("string").str.strip().str.casefold().eq("good").fillna(False)
    if not all_rows:
        out = out.loc[mask].copy()
        mask = pd.Series(True, index=out.index)
    for i, row in out.loc[mask].iterrows():
        r = classify(row["Transcript Threshold S2T"], row["Transcript Threshold NER"], row["Transcript (AI)"], row["Entities Extracted"])
        label, reason, method, confidence, evidence = r.label, r.reason, "rules", "high" if not r.needs_llm else "low", ""
        parsed, valid = parse_entities(row["Entities Extracted"])
        out.at[i, "RCA_Rule_Label"] = r.label
        out.at[i, "RCA_Entity_Checks"] = json.dumps(detail_matches(parsed, row["Transcript (AI)"]), ensure_ascii=False) if valid else "[]"
        out.at[i, "RCA_LLM_Status"] = "not_requested" if not use_llm else "not_required"
        if use_llm and r.needs_llm:
            try:
                from .llm import request_judgement
                data = request_judgement(row.to_dict(), timeout=int(os.getenv("LLM_TIMEOUT", "180")))
                label, reason, method, confidence = data["label"], data["reason"], "llm", data["confidence"]
                evidence = json.dumps(data.get("evidence", []), ensure_ascii=False)
                out.at[i, "RCA_LLM_Label"] = data["label"]
                out.at[i, "RCA_LLM_Status"] = "success"
            except Exception as exc:
                reason = reason + " | LLM error: " + str(exc)[:180]
                method = "rules_llm_failed"
                out.at[i, "RCA_LLM_Status"] = "failed"
        for col, value in zip(RESULT_COLS, (label, reason, method, confidence, evidence, r.candidate)):
            out.at[i, col] = value
    return out


def main():
    load_dotenv()
    ap = argparse.ArgumentParser(description="Root-cause classification: Speech-to-Text vs NER")
    ap.add_argument("--input", required=True, help="Excel (.xlsx) hoặc CSV")
    ap.add_argument("--output", required=True, help="Excel (.xlsx) hoặc CSV")
    ap.add_argument("--sheet", default="0", help="Sheet index hoặc tên sheet trong input XLSX")
    ap.add_argument("--llm", action="store_true", help="LLM đánh giá các trường hợp chưa chắc chắn")
    ap.add_argument("--only-good-rows", action="store_true", help="Chỉ xuất Label=good; mặc định giữ tất cả dòng và cột")
    args = ap.parse_args()
    src, dst = Path(args.input), Path(args.output)
    if not src.exists(): ap.error(f"Không tìm thấy input: {src}")
    if src.resolve() == dst.resolve(): ap.error("Output không được trùng input")
    sheet = int(args.sheet) if args.sheet.isdecimal() else args.sheet
    if src.suffix.lower() == ".xlsx": df = pd.read_excel(src, sheet_name=sheet, dtype=object)
    elif src.suffix.lower() == ".csv": df = pd.read_csv(src, dtype=object, encoding="utf-8-sig")
    else: ap.error("Chỉ hỗ trợ .xlsx hoặc .csv")
    result = process_frame(df, args.llm, all_rows=not args.only_good_rows)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.suffix.lower() == ".xlsx": result.to_excel(dst, index=False)
    elif dst.suffix.lower() == ".csv": result.to_csv(dst, index=False, encoding="utf-8-sig")
    else: ap.error("Output phải là .xlsx hoặc .csv")
    print("DONE", "rows_in:", len(df), "rows_out:", len(result), "classified:", (result["RCA_Label"] != "").sum(), "path:", dst)
    print(result["RCA_Label"].value_counts(dropna=False).to_string())

if __name__ == "__main__": main()
