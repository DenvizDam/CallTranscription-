# Dai-ichi Life Vietnam — S2T / NER Root Cause Classifier (V5)

Công cụ CLI Python để **phân loại nguyên nhân lỗi** trong pipeline `Audio → S2T → NER → Post-process` bằng bảng Excel/CSV. Tùy chọn dùng Qwen qua máy chủ OpenAI-compatible của công ty để phân tích những trường hợp chưa đủ bằng chứng.

> **Phạm vi:** Không đọc/nghe file audio. Một nhãn phân loại dựa trên văn bản và threshold **không phải kết luận tuyệt đối**. Đặc biệt, phép kiểm tra entity xuất hiện trong transcript chỉ là dấu hiệu sơ bộ.

## Cập nhật V5 — giữ nguyên kết quả NER, kiểm tra AMOUNT nghiêm ngặt


**QUY TẮC AMOUNT BẮT BUỘC:** Không được tự chuyển đổi bất cứ giá trị nào trong `Entities Extracted` để biến NER sai thành đúng. `FACEAMOUNT: 250000000` hợp lệ; `FACEAMOUNT: 250 triệu` và `FACEAMOUNT: hai trăm năm mươi triệu` là **lỗi NER định dạng**. Giá trị trong cột gốc vẫn nguyên xi. Ngược lại, phía `Transcript (AI)` được phép diễn giải `250 triệu` thành số để đối chiếu với `250000000`. Điểm trong ngoặc cuối mỗi dòng chỉ bị bỏ khi parse vì không tham gia so sánh. Khi S2T < 1 và NER < 1 mà giá trị AMOUNT sai định dạng, Python gán `Both Phase` (hai phase cùng có dấu hiệu sai theo quy ước threshold). Các lỗi chưa chắc do ngữ cảnh/thiếu entity vẫn được để `Need Review`; có thể bật LLM để kiểm tra.

**Nguyên tắc không thay đổi:** `Entities Extracted` phải so với **`Transcript (AI)`**, không so trực tiếp với Ground Truth để kết luận NER. `TextScript` dùng để tham chiếu sai lệch S2T. Chấp nhận giá trị bằng nhau dù cách biểu diễn khác nhau (`260 triệu = 260000000`). Điểm trong ngoặc sau entity bị loại khỏi phép phân tích.

**Đặc biệt:** Khi S2T < 1 và NER < 1, Python kiểm tra từng giá trị entity với transcript rồi ghi **RCA_Candidate**. Nhưng khớp giá trị **chưa đủ** khẳng định NER đúng loại, ngữ cảnh hay không bỏ sót, nên Python gán `Need Review`. Khi có `--llm`, Qwen phân xử: nếu NER đúng *theo transcript* → `S2T`; nếu S2T sai và NER cũng sai → `Both Phase`; không đủ bằng chứng → `Need Review`. Không mặc định hai threshold cùng thấp là Both Phase.

**Mặc định giữ toàn bộ dòng/cột** của sheet; dòng `Label != good` để trống cột RCA, không phân tích. Tùy chọn `--only-good-rows` chỉ xuất các dòng `good` nếu thực sự cần. Không ghi đè file đầu vào; không ghi đè cột `RCA_*` đã tồn tại.

Các cột kiểm toán bổ sung: `RCA_Rule_Label` (nhãn Python), `RCA_Candidate` (gợi ý từ đối chiếu giá trị), `RCA_Entity_Checks` (chi tiết đối chiếu từng entity với Transcript AI), `RCA_LLM_Label` (nhãn LLM nếu có), `RCA_LLM_Status` (`success`, `failed`, `not_required`, `not_requested`), `RCA_Method`, `RCA_Reason` và `RCA_Confidence`. **Hai output giống nhau không có nghĩa là Qwen đã được gọi**: kiểm tra `RCA_LLM_Status`.

**Giới hạn:** Không nghe audio; không có ngữ cảnh entity được xác thực có thể không đủ kết luận, đặc biệt khi transcript có nhiều số/mã hoặc entity bị thiếu. Hệ thống sẽ ưu tiên `Need Review` hơn khẳng định sai. Bảo vệ dữ liệu cuộc gọi: dùng Git repo private, không commit `.env`, Excel thực tế hoặc file đầu ra; chỉ gửi đến UAT nếu đã được công ty cho phép.

## 1. Điều kiện và quyết định

- Chỉ xử lý dòng có `Label = good` (không phân biệt chữ hoa/thường, bỏ khoảng trắng đầu/cuối).
- **Tất cả cột khác được giữ trong output**; kết quả được bổ sung thêm cột `RCA_*`. **File gốc không bị ghi đè.**
- Mốc `Transcript Threshold S2T` và `Transcript Threshold NER`: `1` nghĩa là đạt mốc, giá trị `<1` nghĩa là có sai lệch. Không tính lại các threshold.

| S2T | NER | Nhãn ban đầu | Giải thích |
|---|---|---|---|
| 1 | 1 | `No Error` | Hai phase đạt mốc |
| 1 | <1 | `NER` | S2T đạt mốc, NER chưa đạt |
| <1 | 1 | `S2T` | NER đạt mốc, S2T chưa đạt |
| <1 | <1 | `Need Review` | Cần kiểm tra đúng loại, giá trị, ngữ cảnh entity và entity bị thiếu. Bật `--llm` để thử phân xử. |
| thiếu/ngoài [0,1] | bất kỳ | `Need Review` | Không đủ dữ liệu hợp lệ |

Nếu cả hai điểm `<1`, rule engine ghi **gợi ý** (`RCA_Candidate`) dựa trên đối chiếu chuỗi hoặc giá trị số tương đương (ví dụ `250 triệu` = `250000000`). Đây không phải nhãn cuối; cách diễn đạt số bằng chữ đầy đủ hoặc trường hợp phức tạp có thể cần LLM kiểm tra. LLM, nếu bật, chỉ đưa ra đánh giá từ văn bản, không có audio; có thể trả `Need Review`.

## 2. Định dạng input

Cần các cột tên **chính xác**:

`Label`, `TextScript`, `Transcript (AI)`, `Transcript Threshold S2T`, `Transcript Threshold NER`, `Entities Extracted`.

Các cột khác như `ID`, `QID`, `Status`, `Quality`, `Entities To Extract`, `Low Confidence Flags`, v.v. được giữ, kể cả các cột chưa được liệt kê ở đây. `Entities To Extract` là ngữ cảnh bổ trợ nếu có, không bắt buộc.

Cột `Entities Extracted` hỗ trợ định dạng nhiều dòng **giống file Excel thực tế**:

```text
FACEAMOUNT: 250000000 (0.0)
PREMIUMTERM: 53 (1.0)
SUNDRYAMOUNT: 22100000 (0.66667)
PREMIUMMODE: năm (1.0)
```

Parser chỉ lấy `ENTITY_TYPE: value` và **không ép kiểu/không sửa `value`**, **bỏ hoàn toàn số trong ngoặc ở cuối dòng**. Không dùng `(0.0)`, `(1.0)`, `(0.66667)` để tính confidence hay phân loại. Ngoài ra hỗ trợ JSON object/list như `{"AGENTCODE":"NV12345"}`. Dữ liệu không parse được được gắn `Need Review`, không tự đoán. Bỏ qua suffix điểm số **chỉ trong phân tích**, cột gốc vẫn được giữ trong output.

## 3. Cài trên Ubuntu/Linux bằng Conda/Miniconda (Python 3.11)

```bash
git clone <YOUR_REPOSITORY_URL>
cd s2t-ner-root-cause
conda create -n s2t_rca python=3.11 -y
conda activate s2t_rca
python -m pip install -r requirements.txt
python -m pip install -e .
cp .env.example .env
```

> Cần cài Conda hoặc Miniconda trước. Nếu `conda activate` chưa hoạt động, chạy `conda init bash`, mở terminal mới rồi kích hoạt lại (với zsh dùng `conda init zsh`). Có thể dùng `conda env create -f environment.yml` thay cho lệnh tạo môi trường và cài thư viện thủ công.
>
> Thay `<YOUR_REPOSITORY_URL>` bằng repository riêng tư của bạn. Không upload dataset/credentials lên GitHub. Không cần tạo `.venv`; CI GitHub Actions và Docker sử dụng Python độc lập, không ảnh hưởng môi trường Conda trên server.

Cấu hình `.env` lấy từ ảnh `qwen_service.py`:

```dotenv
LLM_BASE_URL=https://s2t-vllm-uat.dai-ichi-life.com.vn/v1
LLM_MODEL=Qwen3-Omni-30B-A3B-Instruct
LLM_API_KEY=REPLACE_WITH_SERVER_CREDENTIAL
LLM_TIMEOUT=180
LLM_MAX_RETRIES=2
```

**Quan trọng:** Lấy API key qua kênh quản trị nội bộ và chỉ đặt trên máy chủ. Không copy key hardcode từ hình ảnh/source vào Git. Cần mạng, DNS, chứng chỉ và quyền truy cập môi trường UAT; endpoint chưa được xác minh trực tiếp từ môi trường này.

## 4. Chạy

Đảm bảo đang ở thư mục repository và đã `conda activate s2t_rca` trước khi thực thi lệnh `python`.

```bash
# Chạy bằng rules (không cần mạng / LLM)
python -m rootcause.cli --input examples/sample.csv --output output/sample_rca.csv

# Excel thực tế (mặc định giữ tất cả các dòng, chỉ phân loại Label = good)
python -m rootcause.cli --input input/dataset.xlsx --output output/rca.xlsx

# Rules kết hợp Qwen (gọi khi rules còn chưa chắc chắn)
python -m rootcause.cli --input input/dataset.xlsx --output output/rca_llm.xlsx --llm

# Chỉ xuất dòng Label = good nếu muốn
python -m rootcause.cli --input input/dataset.xlsx --output output/rca_only_good.xlsx --only-good-rows --llm

# Chọn sheet Excel theo tên hoặc số thứ tự (0-based)
python -m rootcause.cli --input input/dataset.xlsx --sheet Sheet1 --output output/result.xlsx

# Kiểm thử
pytest -q
```

**Docker (tùy chọn):**

```bash
docker build -t s2t-ner-rca .
docker run --rm --env-file .env -v "$PWD/input:/workspace/input:ro" -v "$PWD/output:/workspace/output" s2t-ner-rca --input input/dataset.xlsx --output output/rca.xlsx --llm
```

Tạo thư mục `input` / `output` trước khi chạy Docker.

## 5. Output

Bên cạnh các cột gốc, file có:

| Cột | Ý nghĩa |
|---|---|
| `RCA_Label` | `No Error`, `S2T`, `NER`, `Both Phase`, `Need Review` |
| `RCA_Reason` | Lý do bằng tiếng Việt |
| `RCA_Method` | `rules`, `llm`, hoặc `rules_llm_failed` |
| `RCA_Confidence` | high / medium / low, là độ tin cậy **đánh giá** chứ không phải điểm entity gốc |
| `RCA_Evidence` | Dẫn chứng JSON nếu LLM cung cấp |
| `RCA_Candidate` | Nhãn gợi ý ban đầu khi hai threshold dưới 1 (không phải kết luận) |

Dòng ngoài `Label = good` không được phân loại; mặc định bị loại khỏi output, `--all-rows` để giữ nguyên. Nếu LLM lỗi, output vẫn được xuất với `Need Review`, kèm lỗi rút gọn.

## 6. Lưu ý về file và vận hành

- Excel được **đọc và xuất lại dữ liệu theo cột**; không bảo toàn nguyên vẹn màu sắc, công thức, merged cells, format, hay các sheet khác. Nếu cần bảo toàn định dạng workbook gốc, phải triển khai chế độ ghi bổ sung vào file sao chép ở bước tiếp theo.
- Hiện xử lý ở **cấp từng dòng**, chưa xác minh độ chính xác root cause trên một tập đã được chuyên viên gán nhãn.
- Chạy trên dữ liệu được phê duyệt; transcript có thể chứa số hợp đồng, tiền và thông tin cá nhân. Không lưu log toàn văn transcript lên GitHub hay nền tảng bên ngoài. Chỉ dùng LLM khi hạ tầng và chính sách nội bộ cho phép.
- Prompt nằm tại `src/rootcause/llm.py`, engine tại `src/rootcause/engine.py`, CLI tại `src/rootcause/cli.py`, test tại `tests/`.
- Độ chính xác rule engine phụ thuộc ngữ nghĩa hai threshold do người cung cấp xác nhận. Chỉ kiểm chứng dữ liệu thực tế mới chứng minh được chất lượng phân loại.

## 7. Cấu trúc repository

```text
s2t-ner-root-cause/
├── .env.example
├── .gitignore
├── .dockerignore
├── .github/workflows/tests.yml
├── environment.yml          # Tùy chọn: tạo môi trường Conda bằng 1 lệnh
├── Dockerfile
├── README.md
├── pyproject.toml
├── requirements.txt
├── run.py
├── examples/sample.csv
├── src/rootcause/
│   ├── __init__.py
│   ├── cli.py
│   ├── engine.py
│   └── llm.py
└── tests/test_engine.py
```


### Đối chiếu giá trị tiền tệ

Các giá trị tương đương như `250 triệu`, `250.000.000 đồng`, `250000000` được coi là khớp về mặt giá trị. Bộ quy tắc xử lý một số định dạng số phổ biến; các trường hợp đọc bằng chữ đầy đủ hoặc cách nói khác được chuyển cho LLM đánh giá. Việc khớp giá trị không chứng minh entity được gán đúng loại/ngữ cảnh.
