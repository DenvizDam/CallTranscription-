from rootcause.engine import parse_entities, classify, detail_matches, amount_mentions


def test_no_conversion_of_ner_values():
    entries, valid = parse_entities("FACEAMOUNT: 250 triệu (0.0)")
    assert valid and entries[0]["value"] == "250 triệu"
    assert not detail_matches(entries, "Số tiền 250 triệu")[0]["format_valid"]
    assert classify(.8, .7, "Số tiền 250 triệu", "FACEAMOUNT: 250 triệu (0.0)").label == "Both Phase"


def test_numeric_amount_matched_to_spoken_transcript():
    entities = "FACEAMOUNT: 250000000 (0.0)\nPREMIUMTERM: 53 (1.0)\nSUNDRYAMOUNT: 22100000 (1.0)\nPREMIUMMODE: năm (1.0)"
    transcript = "Số tiền bảo hiểm 250 triệu đồng, 53 năm, phí dự tính 22 triệu 100 nghìn đồng, định kỳ đóng phí năm"
    parsed, valid = parse_entities(entities)
    assert valid and all(x["format_valid"] and x["value_found"] for x in detail_matches(parsed, transcript))
    r = classify(.8, .7, transcript, entities)
    assert r.label == "Need Review" and r.candidate == "S2T"
    assert 22100000 in amount_mentions(transcript)


def test_amount_wrong_numeric():
    r = classify(.8,.7,"Số tiền bảo hiểm 250 triệu", "FACEAMOUNT: 260000000 (0.0)")
    assert r.label == "Need Review" and r.candidate == "Both Phase"


def test_parser_does_not_change_other_types():
    data, ok = parse_entities("AGENTCODE: NV001 (0.66667)\nPREMIUMMODE: năm (1.0)")
    assert ok and data == [{"type":"AGENTCODE","value":"NV001"},{"type":"PREMIUMMODE","value":"năm"}]
