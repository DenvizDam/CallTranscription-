"""Deterministic triage. Thresholds are flags, NOT root-cause proof."""
import ast
import decimal
import json
import math
import re
import unicodedata
from dataclasses import dataclass
from typing import Any


@dataclass
class Result:
    label: str
    reason: str
    needs_llm: bool = False
    candidate: str = ""


def missing(value: Any) -> bool:
    if value is None: return True
    if isinstance(value, float) and math.isnan(value): return True
    return isinstance(value, str) and not value.strip()


def score(value: Any) -> float | None:
    if missing(value): return None
    try:
        number = float(str(value).strip().replace(",", "."))
        return number if math.isfinite(number) and 0 <= number <= 1 else None
    except (TypeError, ValueError): return None


def normalize(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value)).casefold().strip()


def parse_entities(raw: Any) -> tuple[list[dict], bool]:
    """Supports JSON dict/list, list of {type,value}, or Python literal.

    A plain unstructured string must be reviewed rather than falsely treated as valid.
    """
    if missing(raw): return [], False
    # Excel multiline format: ENTITY_NAME: value (numeric-score). Score is deliberately ignored.
    if isinstance(raw, str) and not raw.lstrip().startswith(('{', '[')):
        rows = [line.strip() for line in raw.splitlines() if line.strip()]
        if not rows:
            return [], False
        parsed = []
        for line in rows:
            match = re.fullmatch(r"([A-Za-z][A-Za-z0-9_ .-]*)\s*:\s*(.+?)\s*", line)
            if not match:
                return [], False
            name, value = match.group(1).strip(), match.group(2).strip()
            # Remove only a numeric parenthesized suffix (not parentheses inside an entity value).
            value = re.sub(r"\s*\(\s*[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)\s*\)\s*$", "", value).strip()
            if not value:
                return [], False
            parsed.append({"type": name, "value": value})
        return parsed, True
    value = raw
    if isinstance(raw, str):
        try: value = json.loads(raw)
        except (ValueError, TypeError):
            try: value = ast.literal_eval(raw)
            except (SyntaxError, ValueError): return [], False
    entries = []
    if isinstance(value, dict):
        if "type" in value and "value" in value:
            entries = [{"type": str(value["type"]), "value": str(value["value"])}]
        else:
            for k, v in value.items():
                vals = v if isinstance(v, list) else [v]
                for x in vals:
                    if isinstance(x, (str, int, float)) and not missing(x):
                        entries.append({"type": str(k), "value": str(x)})
                    elif isinstance(x, dict) and "value" in x:
                        entries.append({"type": str(k), "value": str(x["value"])})
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, dict) and "type" in item and "value" in item:
                entries.append({"type": str(item["type"]), "value": str(item["value"])})
            else: return [], False
    else: return [], False
    return entries, True


def numeric_equivalent_in_transcript(value: str, transcript: str) -> bool:
    """Conservative matching for Vietnamese amounts (e.g. 250 triệu = 250000000).

    This is evidence of value presence, NOT proof of correct entity role/context.
    """
    import decimal
    normalized = normalize(transcript)
    normalized = re.sub(r"(?<=\d)[.,](?=\d{3}(?:\D|$))", "", normalized)
    normalized = normalized.replace("đồng", " đồng ")
    raw = normalize(value).replace(" ", "")
    try:
        expected = decimal.Decimal(raw.replace(".", "").replace(",", ""))
    except decimal.InvalidOperation:
        return False
    if not expected.is_finite():
        return False
    # Boundaries prevent a match against a prefix/suffix of a longer number.
    for m in re.finditer(r"(?<![\w])([0-9]+(?:[.,][0-9]+)?)\s*(nghìn|ngàn|triệu|tỷ|tỉ)?(?![\w])", normalized):
        number, unit = m.groups()
        try:
            base = decimal.Decimal(number.replace(",", "."))
        except decimal.InvalidOperation:
            continue
        multiplier = {None: 1, "nghìn": 1000, "ngàn": 1000, "triệu": 1000000, "tỷ": 1000000000, "tỉ": 1000000000}[unit]
        if base * multiplier == expected:
            return True
    return False


def presence(entries: list[dict], transcript: Any) -> bool:
    t = normalize(transcript)
    if not t or not entries: return False
    # Strict literal substring: this is ONLY a preliminary test, not proof of correct NER.
    return all(
        (bool(re.search(r"(?<![\w])" + re.escape(normalize(e["value"])) + r"(?![\w])", t))
         or numeric_equivalent_in_transcript(e["value"], t))
        for e in entries
    )


# Đây chỉ là bằng chứng khớp GIÁ TRỊ, không mặc định chứng minh đúng nhãn hoặc ngữ cảnh.
ROLE_HINTS = {
    "FACEAMOUNT": ("mệnh giá", "số tiền bảo hiểm", "quyền lợi bảo hiểm"),
    "SUNDRYAMOUNT": ("phí phụ", "phí bổ sung", "số tiền bổ sung"),
    "PREMIUMTERM": ("thời hạn đóng phí", "thời hạn phí", "đóng phí trong"),
    "PREMIUMMODE": ("định kỳ đóng phí", "phương thức đóng phí", "đóng phí theo"),
    "AGENTCODE": ("mã nhân viên", "mã tư vấn viên", "mã đại lý"),
}


def detail_matches(entries: list[dict], transcript: Any) -> list[dict]:
    """So khớp từng value với Transcript (AI), KHÔNG dùng TextScript để phán lỗi NER."""
    t = normalize(transcript)
    items = []
    for ent in entries:
        value = normalize(ent['value'])
        literal = bool(value and re.search(r"(?<![\w])" + re.escape(value) + r"(?![\w])", t))
        numeric = numeric_equivalent_in_transcript(value, t)
        matched = literal or numeric
        hints = ROLE_HINTS.get(str(ent['type']).upper(), ())
        # Keyword toàn transcript không đủ bảo đảm value nằm đúng ngữ cảnh.
        role_hint_found = bool(hints and any(h in t for h in hints))
        items.append({"type": ent['type'], "value": ent['value'],
                      "value_found": matched, "match_mode": "literal" if literal else "numeric" if numeric else "none",
                      "role_hint_in_transcript": role_hint_found})
    return items


def classify(s2t_raw: Any, ner_raw: Any, transcript: Any, entities_raw: Any) -> Result:
    s, n = score(s2t_raw), score(ner_raw)
    if s is None or n is None: return Result("Need Review", "Thiếu hoặc sai định dạng threshold")
    if s == 1 and n == 1: return Result("No Error", "Hai threshold đều đạt mốc 1")
    if s == 1 and n < 1: return Result("NER", "S2T đạt mốc; NER dưới mốc")
    if s < 1 and n == 1: return Result("S2T", "S2T dưới mốc; NER đạt mốc")
    if missing(transcript): return Result("Need Review", "Thiếu Transcript (AI); không thể kiểm tra NER", True)
    entries, valid = parse_entities(entities_raw)
    if not valid or not entries:
        return Result("Need Review", "Entities Extracted trống hoặc không parse được; chưa đủ bằng chứng", True)
    checks = detail_matches(entries, transcript)
    found = sum(int(x['value_found']) for x in checks)
    if found == len(checks):
        return Result("Need Review", f"{found}/{len(checks)} entity có giá trị khớp Transcript (AI), nhưng cần xác minh loại/ngữ cảnh và entity bị thiếu", True, "S2T")
    return Result("Need Review", f"Chỉ {found}/{len(checks)} entity khớp Transcript (AI); có thể khác cách đọc hoặc lỗi NER, cần xác minh", True, "Both Phase")
