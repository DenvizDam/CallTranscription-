import pandas as pd
from rootcause.engine import classify, parse_entities, presence
from rootcause.cli import process_frame

def test_basic():
    assert classify(1,1,"","").label == "No Error"
    assert classify(1,.7,"","").label == "NER"
    assert classify(.8,1,"","").label == "S2T"
    assert classify(.8,.7,"NV12346",'{"agentcode":"NV12346"}').label == "Need Review"
    assert classify(.8,.7,"NV12346",'{"agentcode":"NV99999"}').label == "Need Review"

def test_missing():
    assert classify(None,.4,"abc", "{}").label == "Need Review"
    assert classify(.4,.4,"abc", "raw text").label == "Need Review"

def test_parser():
    ents, ok = parse_entities('{"agentcode": "NV12346"}')
    assert ok and presence(ents, "Mã NV12346")
    assert not presence(ents, "Mã NV12345")

def test_preserves_columns_and_filter():
    src = pd.DataFrame([{"Label":"good", "TextScript":"hi", "Transcript (AI)":"hi", "Transcript Threshold S2T":1, "Transcript Threshold NER":1, "Entities Extracted":"{}", "Extra":"keep"},
                        {"Label":"bad", "TextScript":"hi", "Transcript (AI)":"hi", "Transcript Threshold S2T":1, "Transcript Threshold NER":1, "Entities Extracted":"{}", "Extra":"keep2"}])
    o = process_frame(src)
    assert len(o) == 1 and o.iloc[0]["Extra"] == "keep"
    a = process_frame(src, all_rows=True)
    assert len(a) == 2 and a.iloc[1]["RCA_Label"] == ""

def test_multiline_format_and_scores_ignored():
    data = "FACEAMOUNT: 250000000 (0.0)\nPREMIUMTERM: 53 (1.0)\nSUNDRYAMOUNT: 22100000 (0.66667)\nPREMIUMMODE: năm (1.0)"
    entries, valid = parse_entities(data)
    assert valid
    assert entries == [
        {"type": "FACEAMOUNT", "value": "250000000"},
        {"type": "PREMIUMTERM", "value": "53"},
        {"type": "SUNDRYAMOUNT", "value": "22100000"},
        {"type": "PREMIUMMODE", "value": "năm"},
    ]
    assert parse_entities("POLICYOWNER: Xuân Sơn (0.66667)")[0][0]["value"] == "Xuân Sơn"
    assert not parse_entities("FACEAMOUNT: (0.0)")[1]
    assert not parse_entities("FACEAMOUNT: 123 (1.0)\ninvalid line")[1]

def test_multiline_routing():
    assert classify(.8, .7, "Mệnh giá 250000000", "FACEAMOUNT: 250000000 (0.0)").candidate == "S2T"
    assert classify(.8, .7, "Mệnh giá 300000000", "FACEAMOUNT: 250000000 (0.0)").candidate == "Both Phase"


def test_amount_semantic_matching():
    assert presence([{"type": "FACEAMOUNT", "value": "250000000"}], "Số tiền là 250 triệu đồng")
    assert presence([{"type": "FACEAMOUNT", "value": "250000000"}], "Số tiền là 250.000.000 đồng")
    assert presence([{"type": "FACEAMOUNT", "value": "2500000000"}], "Số tiền là 2,5 tỷ đồng")
    assert not presence([{"type": "FACEAMOUNT", "value": "250000000"}], "Số tiền là 260 triệu đồng")
    assert not presence([{"type": "FACEAMOUNT", "value": "250000000"}], "Số tiền là 2500000000 đồng")
    assert classify(.8,.7,"Mệnh giá 250 triệu đồng", "FACEAMOUNT: 250000000 (0.0)").candidate == "S2T"
