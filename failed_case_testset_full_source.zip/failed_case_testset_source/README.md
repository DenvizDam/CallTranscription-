# Failed Case Test Set Builder

Python script that builds WAV + decoded metadata JSON pairs from PRD data, driven by a filtered Excel sheet.

## Requirements

- Python 3.9+ (3.10+ recommended).
- No third-party packages. Standard library only.
- Read access to the Excel workbook and `data_PRD/audios`, `data_PRD/payloads` trees.
- Write access to the destination folder.
- Source WAV/payload files are never modified.

## Source placement (on the server)

Copy `20261008_db_analysis_Q3_2026.xlsx` to the folder containing this script, or specify another accessible Excel path with `--excel`.

Example layout:

```text
testset/
├── build_failed_case_testset.py
├── 20261008_db_analysis_Q3_2026.xlsx
├── data_PRD/
│   ├── audios/2026/09/30/.../qid_<UUID>.wav
│   └── payloads/2026/09/30/.../qid_<UUID>_corrid_<ID>.json
└── failed_case_testset/   # Created by script
```

**Server path note:** On a Windows machine accessing the share, `--data-root "\\\\10.166.2.165\\project\\speechtotext\\testset\\data_PRD"` works if the share is available. If code runs on Linux, Windows UNC paths do NOT automatically work: use the Linux mount path (for example `/mnt/share/project/speechtotext/testset/data_PRD`) and the equivalent absolute path to the Excel file.

## Run

From the directory containing the script:

```bash
python build_failed_case_testset.py --dry-run
python build_failed_case_testset.py
```

With explicit absolute paths:

```bash
python build_failed_case_testset.py \
  --excel "/path/on/server/20261008_db_analysis_Q3_2026.xlsx" \
  --data-root "/path/on/server/data_PRD" \
  --output "/path/on/server/failed_case_testset" \
  --dry-run
```

Windows PowerShell (single line):

```powershell
python .\build_failed_case_testset.py --excel "C:\path\to\20261008_db_analysis_Q3_2026.xlsx" --data-root "\\10.166.2.165\project\speechtotext\testset\data_PRD" --output "\\10.166.2.165\project\speechtotext\testset\failed_case_testset" --dry-run
```

Remove `--dry-run` after checking the report.

## Matching rules

- Excel sheet: `DB Records`. The script finds headers `QID`, `Quality`, `Label` by their contents (not fixed column position).
- Row condition: `Quality == "Non-Perfect"` **AND** `Label == "good"` (exact case).
- Valid QID: full UUID (format `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`).
- Audio filename: `qid_<QID>.wav` (case-insensitive extension).
- Payload filename: `qid_<QID>_corrid_<anything>.json`.
- Audio and payload are searched **recursively** under their respective `data_PRD` subfolders; paths and date folders need not align.
- One WAV and one payload must be found for a successful pair. Duplicates are **reported, not selected arbitrarily**.
- Payload `metadata` can be a JSON-encoded string or already a JSON object. Output is the decoded object itself with `Keywords` at top-level. All values within metadata are preserved.
- Valid output metadata must contain a top-level `Keywords` **array**.
- All source audio and payload files are left unchanged.

## Output

```text
failed_case_testset/
├── cases/
│   └── <QID>/
│       ├── audio.wav
│       └── metadata.json
├── matching_report.csv
└── summary.json
```

`matching_report.csv` is an Excel-friendly UTF-8 BOM CSV report, **not an `.xlsx` workbook**; open it directly in Excel. CSV is chosen to avoid dependencies on the server.

Statuses: `COMPLETE`, `DRY_RUN_READY`, `ALREADY_EXISTS`, `MISSING_AUDIO`, `MISSING_PAYLOAD`, `MISSING_BOTH`, `DUPLICATE_FILES`, `INVALID_METADATA`.

An existing case directory is **not overwritten**. To regenerate it, move/remove that output directory deliberately, then rerun. Other cases are not affected.

Exit status: 0 = no missing/invalid/duplicate cases, 2 = some cases incomplete (see report), 1 = fatal error (such as inaccessible Excel or source directory). Dry run still creates the report and summary but never copies case files.

## Operational precautions

- Payloads and metadata can contain personal/customer data. Keep outputs inside approved company storage, restrict access and avoid uploading to external services.
- Verify `matching_report.csv` and `summary.json` before using the test set.
- The script reads the cell values in Excel. It does not rely on Excel's currently displayed UI filter state.
- `.xlsx` supported (not old `.xls`, password-protected workbooks or formula-only values missing cached results).
